# 🏆 Redrob Intelligent Candidate Ranking System

> **Hackathon submission for the Redrob Intelligent Candidate Discovery & Ranking Challenge**
> Ranks 100,000 candidates against a Senior AI Engineer JD in **under 25 seconds** on CPU.

---

## Overview

A production-grade, multi-signal candidate ranking system that goes far beyond keyword matching. It understands the *gap between what the JD says and what the JD means* — rewarding candidates who shipped production ML systems, downweighting ghost candidates, and filtering out honeypots automatically.

**Key results:**
| Metric | Value |
|--------|-------|
| Wall-clock runtime | **~22 seconds** (100K candidates, CPU-only) |
| Candidates processed | 100,000 |
| Honeypots detected & excluded | ~473 in pre-filtered pool |
| Submission format | ✅ Passes official validator |
| Top-10 precision (proxy) | High — all top-10 are applied ML engineers |

---

## Architecture

```
candidates.jsonl (100K)
        │
        ▼
┌─────────────────────┐
│  Stage-0 Pre-filter  │  keyword scan on raw JSONL → ~8,000 ML-signal candidates
│  (src/prefilter.py) │  runs in 12 seconds, no parsing
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│  Candidate Parser   │  extract 30+ features per candidate
│ (src/candidate_     │  (skills, career trajectory, honeypot detection,
│   parser.py)        │   production ML signals, company type, etc.)
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│  TF-IDF Embedder    │  bigram TF-IDF over candidate text blobs
│  (src/embeddings.py)│  → cosine similarity vs JD text blob
│  [FAISS-ready]      │  swap in sentence-transformers + FAISS when available
└────────┬────────────┘
         │
         ▼  top-500 candidates
┌─────────────────────┐
│  Multi-Signal Scorer│  7 weighted components:
│  (src/scoring.py)   │  skill_match (30%) · experience (20%) · domain (20%)
│                     │  career_growth (10%) · behavioral (10%)
│                     │  location (5%) · education (5%)
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│  Rule-Based Reranker│  JD-specific boosts & penalties:
│  (src/reranker.py)  │  · shipped ranking/retrieval system → ×1.08
│                     │  · consulting-only career → ×0.40
│                     │  · inactive 6+ months → ×0.50
│                     │  · honeypot → excluded
└────────┬────────────┘
         │
         ▼  top-100
┌─────────────────────┐
│  Explainability     │  fact-grounded 1-2 sentence reasoning per candidate
│  (src/explainability│  references: title, YOE, named skills, location,
│   .py)              │  signals, honest concerns
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│  Output Generator   │  ranked_candidates.csv (submission-spec compliant)
│  (src/output_       │  detailed_report.json (Stage 4 manual review)
│   generator.py)     │
└─────────────────────┘
```

---

## Repository Structure

```
redrob-ranker/
├── app.py                      # Main pipeline entry point
├── requirements.txt
├── submission_metadata.yaml
├── README.md
│
├── src/
│   ├── __init__.py
│   ├── prefilter.py            # Stage-0 fast keyword pre-filter
│   ├── data_loader.py          # JSONL / JSONL.gz streaming loader
│   ├── jd_parser.py            # JD → structured ParsedJD + text blob
│   ├── candidate_parser.py     # Raw record → 30+ feature dict
│   ├── embeddings.py           # TF-IDF embedder (FAISS/ST drop-in ready)
│   ├── retrieval.py            # Top-K retrieval (TFIDFRetriever / FaissRetriever)
│   ├── scoring.py              # 7-component composite scorer
│   ├── reranker.py             # Rule-based re-ranker with JD-specific filters
│   ├── explainability.py       # Fact-grounded reasoning generator
│   ├── output_generator.py     # CSV + JSON report writer
│   └── evaluation.py           # NDCG, MAP, Precision@K, hackathon composite
│
├── outputs/
│   ├── submission.csv          # Final submission (100 rows)
│   └── detailed_report.json    # Full breakdown for Stage 4 review
│
└── tests/
    └── test_pipeline.py        # Unit + integration tests
```

---

## Setup

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/redrob-ranker
cd redrob-ranker

# Install dependencies (all standard packages)
pip install -r requirements.txt

# Place the dataset
cp /path/to/candidates.jsonl .
```

---

## Usage

```bash
# Standard run (produces outputs/submission.csv)
python app.py --candidates candidates.jsonl --out outputs/submission.csv

# Full options
python app.py \
    --candidates    candidates.jsonl \
    --out           outputs/team_redrob.csv \
    --prefilter-max 8000 \
    --top-k         500 \
    --top-n         100 \
    --report        outputs/detailed_report.json \
    --log-level     INFO
```

**Runtime:** ~22 seconds on CPU with 4 GB RAM.

---

## Scoring Components

| Component | Weight | What it measures |
|-----------|--------|-----------------|
| `skill_match` | 30% | TF-IDF cosine sim + direct skill overlap + proficiency-weighted quality |
| `experience` | 20% | YOE in 5–9 band + product-company fraction + production ML signal |
| `domain` | 20% | Shipped ranking/retrieval/recommendation system; ML title; ML career fraction |
| `career_growth` | 10% | Title progression; avg tenure; anti-job-hopping |
| `behavioral` | 10% | Activity recency, recruiter response rate, interview completion, GitHub |
| `location` | 5% | Target cities (Noida/Pune/Hyd/Blr/Mumbai/Delhi NCR) or willing to relocate |
| `education` | 5% | Institution tier (IIT/IISc=1 → tier4=4); CS/STEM field |

**Final score** = weighted_sum × behavioral_availability_multiplier

---

## Honeypot Detection

The system automatically detects and excludes honeypot candidates via:
1. **Expert skills with 0 months** of usage (impossible profile)
2. **Total career months > claimed YOE × 12 + 36** (chronologically impossible)
3. **Salary range inverted** (min > max × 1.5)
4. **Title disqualifiers** — candidates whose entire career is non-ML receive a ×0.25 multiplier

---

## Evaluation Strategy

The hackathon composite metric:
```
Composite = 0.50 × NDCG@10 + 0.30 × NDCG@50 + 0.15 × MAP + 0.05 × P@10
```

All metrics are implemented in `src/evaluation.py`. Without ground truth we use a score-binning proxy (grades 0–3) for internal validation. The `hackathon_composite()` function accepts any ground-truth relevance dict for plug-in evaluation.

---

## Compute Constraints (met)

| Constraint | Limit | Our system |
|------------|-------|-----------|
| Runtime | ≤5 min | ~22 sec |
| RAM | ≤16 GB | ~1.5 GB |
| Compute | CPU only | ✅ |
| Network | Off | ✅ (no API calls) |
| GPU | Off | ✅ |

---

## FAISS / Sentence-Transformers Upgrade Path

The architecture is designed for easy upgrade:

```python
# In src/retrieval.py — swap one line:
# from .retrieval import TFIDFRetriever     # current
from .retrieval import FaissRetriever        # when faiss-cpu is available

# In src/embeddings.py — one-line swap:
embedder = build_embedder(prefer_sentence_transformers=True)
```

Recommended upgrade models:
- `BAAI/bge-small-en-v1.5` (fast, good quality)
- `BAAI/bge-base-en-v1.5` (better quality, slower)
- `cross-encoder/ms-marco-MiniLM-L-6-v2` (cross-encoder re-ranker)

---

## AI Tools Declaration

- **Claude**: Architecture discussion, code review, prompt design
- **GitHub Copilot**: Autocomplete assistance

No candidate data was fed to any LLM. All ranking logic runs locally.

---

## Future Improvements

1. **Dense embeddings**: Replace TF-IDF with BGE/E5 sentence transformers for semantic matching
2. **Cross-encoder re-ranker**: Use a fine-tuned cross-encoder on (JD, candidate) pairs
3. **Online learning**: Collect recruiter feedback signals to fine-tune scores
4. **LLM re-ranking**: Use a local LLM (Mistral-7B) for top-50 cross-attention scoring
5. **Graph signals**: Build candidate similarity graphs to identify "behavioral twins"
6. **Evaluation harness**: A/B test different scoring weights against recruiter engagement metrics
