#!/usr/bin/env python3
"""
app.py — Redrob Hackathon Ranking Pipeline (Two-Pass Architecture)
==================================================================
Pass 0  : Fast keyword pre-filter on raw JSONL → ~5 000 candidates
Pass 1  : Full candidate feature extraction on pre-filtered pool
Pass 2  : TF-IDF index + cosine retrieval → top-500
Pass 3  : Multi-signal scoring (skill, experience, domain, behavioral …)
Pass 4  : Rule-based re-ranking (anti-pattern filters + boosts)
Pass 5  : Explainability (reasoning generation)
Pass 6  : Output CSV + detailed JSON report

Usage
-----
  python app.py --candidates candidates.jsonl --out outputs/submission.csv
"""

import argparse
import logging
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.prefilter        import prefilter_candidates
from src.jd_parser        import parse_jd, JD_TEXT
from src.candidate_parser import parse_candidate
from src.retrieval        import TFIDFRetriever
from src.scoring          import score_all
from src.reranker         import RuleBasedReranker
from src.explainability   import generate_all_reasonings
from src.output_generator import generate_csv, generate_detailed_report
from src.evaluation       import self_evaluate


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Redrob Candidate Ranking Pipeline")
    p.add_argument("--candidates", "-c", default="candidates.jsonl")
    p.add_argument("--out",        "-o", default="outputs/submission.csv")
    p.add_argument("--top-k",   type=int, default=500,
                   help="TF-IDF retrieval pool size (default 500)")
    p.add_argument("--top-n",   type=int, default=100,
                   help="Final submission size (default 100)")
    p.add_argument("--prefilter-max", type=int, default=8000,
                   help="Max candidates after stage-0 pre-filter (default 8000)")
    p.add_argument("--report",  default="outputs/detailed_report.json")
    p.add_argument("--log-level", default="INFO",
                   choices=["DEBUG","INFO","WARNING","ERROR"])
    return p.parse_args()


def _banner(msg: str) -> None:
    logger = logging.getLogger("app")
    logger.info("=" * 60)
    logger.info(msg)
    logger.info("=" * 60)


def run_pipeline(
    candidates_path : str,
    output_csv_path : str,
    top_k           : int  = 500,
    top_n           : int  = 100,
    prefilter_max   : int  = 8000,
    report_path     : str  = "outputs/detailed_report.json",
) -> None:
    logger  = logging.getLogger("app")
    t_start = time.time()

    # ── STEP 1: Parse JD ─────────────────────────────────────────────────────
    _banner("STEP 1: Parsing Job Description")
    pjd = parse_jd(JD_TEXT)
    logger.info("Required skills: %d  |  Preferred: %d  |  Exp: %d–%d yrs",
                len(pjd.required_skills), len(pjd.preferred_skills),
                pjd.experience_min_years, pjd.experience_max_years)

    # ── STEP 2: Stage-0 pre-filter (fast keyword scan on raw JSONL) ───────────
    _banner("STEP 2: Stage-0 Pre-filter (fast keyword scan)")
    raw_candidates = prefilter_candidates(candidates_path, max_pass=prefilter_max)
    logger.info("Pre-filter kept %d candidates.", len(raw_candidates))

    # ── STEP 3: Full feature extraction ───────────────────────────────────────
    _banner("STEP 3: Parsing Candidate Features")
    t3 = time.time()
    candidate_features = [parse_candidate(r) for r in raw_candidates]
    honeypots = sum(1 for f in candidate_features if f["is_honeypot"])
    logger.info("Parsed %d features in %.1f s  |  Honeypots: %d",
                len(candidate_features), time.time() - t3, honeypots)

    # ── STEP 4: TF-IDF retrieval ──────────────────────────────────────────────
    _banner(f"STEP 4: TF-IDF Index & Retrieve Top-{top_k}")
    retriever = TFIDFRetriever(top_k=min(top_k, len(candidate_features)))
    retriever.build_index(candidate_features)
    top_ids, tfidf_scores = retriever.retrieve(pjd.text_blob)

    tfidf_map     = dict(zip(top_ids, tfidf_scores.tolist()))
    retrieved_set = set(top_ids)
    retrieved_feats = [f for f in candidate_features
                       if f["candidate_id"] in retrieved_set]
    logger.info("Retrieved %d candidates for re-ranking.", len(retrieved_feats))

    # ── STEP 5: Multi-signal scoring ──────────────────────────────────────────
    _banner("STEP 5: Multi-Signal Scoring")
    scored = score_all(retrieved_feats, tfidf_map)
    logger.info("Top composite score: %.4f", scored[0]["final_score"] if scored else 0)

    # ── STEP 6: Re-ranking ────────────────────────────────────────────────────
    _banner("STEP 6: Rule-Based Re-Ranking")
    reranker = RuleBasedReranker(top_n=top_n, pool_k=top_k)
    ranked   = reranker.rerank(scored, pjd.required_skills)

    # Safety pad: if still short, fill from scored list
    if len(ranked) < top_n:
        logger.warning("Only %d after rerank; padding from scored list.", len(ranked))
        existing = {r["candidate_id"] for r in ranked}
        extra_rank = len(ranked) + 1
        for item in scored:
            if item["candidate_id"] not in existing:
                item["rank"]           = extra_rank
                item["reranked_score"] = round(item["final_score"] * 0.6, 6)
                ranked.append(item)
                existing.add(item["candidate_id"])
                extra_rank += 1
            if len(ranked) >= top_n:
                break

    # ── STEP 7: Explainability ────────────────────────────────────────────────
    _banner("STEP 7: Generating Explanations")
    ranked = generate_all_reasonings(ranked)

    # ── STEP 8: Write outputs ─────────────────────────────────────────────────
    _banner("STEP 8: Writing Outputs")
    csv_out    = generate_csv(ranked, output_csv_path, top_n=top_n)
    rpt_out    = generate_detailed_report(ranked, report_path, top_n=top_n)

    # ── STEP 9: Self-evaluation ───────────────────────────────────────────────
    _banner("STEP 9: Self-Evaluation (proxy metrics)")
    metrics = self_evaluate(ranked)
    for k, v in metrics.items():
        logger.info("  %-12s = %.4f", k, v)

    elapsed = time.time() - t_start
    _banner(f"Pipeline complete in {elapsed:.1f}s")
    logger.info("Submission CSV  : %s", csv_out)
    logger.info("Detailed report : %s", rpt_out)

    # ── Print top-10 ──────────────────────────────────────────────────────────
    print("\n" + "="*80)
    print("🏆  TOP-10 RANKED CANDIDATES")
    print("="*80)
    for item in ranked[:10]:
        f = item["feat"]
        print(f"  #{item['rank']:>3}  {f['candidate_id']}  "
              f"score={item['reranked_score']:.4f}  "
              f"{f['current_title'][:28]:<28}  {f['location']}")
        print(f"       ↳ {item['reasoning'][:110]}")
        print()
    print("="*80)


def main() -> None:
    args = parse_args()
    setup_logging(args.log_level)
    run_pipeline(
        candidates_path = args.candidates,
        output_csv_path = args.out,
        top_k           = args.top_k,
        top_n           = args.top_n,
        prefilter_max   = args.prefilter_max,
        report_path     = args.report,
    )


if __name__ == "__main__":
    main()
