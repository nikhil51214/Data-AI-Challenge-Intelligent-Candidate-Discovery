"""
build_presentation.py
Creates a 10-slide hackathon presentation using python-pptx.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
import json, os

# ── Colors ────────────────────────────────────────────────────────────────────
BG_DARK   = RGBColor(0x0D, 0x11, 0x17)   # github dark
BG_CARD   = RGBColor(0x16, 0x1B, 0x22)
ACCENT    = RGBColor(0x23, 0x86, 0x36)   # green
ACCENT2   = RGBColor(0x38, 0x8B, 0xFD)   # blue
ACCENT3   = RGBColor(0xA3, 0x71, 0xF7)   # purple
WHITE     = RGBColor(0xF0, 0xF6, 0xFC)
MUTED     = RGBColor(0x8B, 0x94, 0x9E)
RED       = RGBColor(0xF7, 0x81, 0x66)
GOLD      = RGBColor(0xE3, 0xB3, 0x41)

W  = Inches(13.33)
H  = Inches(7.5)

prs = Presentation()
prs.slide_width  = W
prs.slide_height = H

def blank_slide():
    layout = prs.slide_layouts[6]   # completely blank
    return prs.slides.add_slide(layout)

def bg(slide, color=BG_DARK):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_rect(slide, x, y, w, h, fill_color, alpha=None):
    shape = slide.shapes.add_shape(1, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.line.fill.background()
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    return shape

def add_text(slide, text, x, y, w, h, size=18, bold=False,
             color=WHITE, align=PP_ALIGN.LEFT, italic=False):
    txb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf  = txb.text_frame
    tf.word_wrap = True
    p   = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size  = Pt(size)
    run.font.bold  = bold
    run.font.italic= italic
    run.font.color.rgb = color
    run.font.name  = "Calibri"
    return txb

def add_bullet_box(slide, items, x, y, w, h, size=14, color=WHITE, bullet_color=ACCENT):
    txb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf  = txb.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_before = Pt(4)
        run = p.add_run()
        run.text = f"▸  {item}"
        run.font.size  = Pt(size)
        run.font.color.rgb = color
        run.font.name  = "Calibri"
    return txb

def slide_header(slide, title, subtitle=None, title_color=WHITE, accent_color=ACCENT):
    """Adds a title block at the top of a dark slide."""
    add_text(slide, title, 0.5, 0.25, 12.3, 0.9,
             size=36, bold=True, color=title_color, align=PP_ALIGN.LEFT)
    if subtitle:
        add_text(slide, subtitle, 0.5, 1.05, 12.3, 0.45,
                 size=17, color=MUTED, align=PP_ALIGN.LEFT)
    # thin accent line under title
    bar = slide.shapes.add_shape(1, Inches(0.5), Inches(1.45), Inches(12.3), Emu(60000))
    bar.fill.solid(); bar.fill.fore_color.rgb = accent_color
    bar.line.fill.background()

def card(slide, x, y, w, h, fill=BG_CARD):
    shape = slide.shapes.add_shape(5, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb = fill
    shape.line.color.rgb = RGBColor(0x30,0x36,0x3D)
    shape.line.width = Pt(1)
    return shape

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 1 — Title
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
add_rect(sl, 0, 0, 13.33, 7.5, BG_DARK)
add_rect(sl, 0, 0, 0.5, 7.5, ACCENT)
add_text(sl, "Redrob Intelligent", 0.9, 1.2, 11, 1.1, size=48, bold=True,
         color=WHITE, align=PP_ALIGN.LEFT)
add_text(sl, "Candidate Ranking System", 0.9, 2.2, 11, 1.1, size=48, bold=True,
         color=ACCENT, align=PP_ALIGN.LEFT)
add_text(sl, "AI-powered · Explainable · Production-grade · CPU-only · 22 seconds for 100K candidates",
         0.9, 3.5, 11, 0.5, size=15, color=MUTED, align=PP_ALIGN.LEFT)

for i, (label, val) in enumerate([
    ("Runtime", "22 sec"), ("Candidates", "100K"), ("Compute", "CPU only"), ("Validator", "✅ Pass")
]):
    cx = 0.9 + i * 3.1
    card(sl, cx, 4.5, 2.7, 1.4)
    add_text(sl, val,   cx+0.15, 4.65, 2.4, 0.6, size=28, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
    add_text(sl, label, cx+0.15, 5.2,  2.4, 0.5, size=13, color=MUTED, align=PP_ALIGN.CENTER)

add_text(sl, "Hackathon Submission — Redrob AI Challenge 2025",
         0.9, 6.8, 11, 0.4, size=11, color=MUTED, align=PP_ALIGN.LEFT, italic=True)

sl.notes_slide.notes_text_frame.text = (
    "Introduce the team and the challenge. Emphasize: we built a full production-grade "
    "system in Python — no API calls, CPU-only, 22 seconds for 100K candidates. "
    "All code in GitHub, validator passes, reasoning is grounded in profile facts."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 2 — Problem
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "The Problem", "Finding the right AI engineer in a 100K candidate pool", accent_color=RED)

add_bullet_box(sl, [
    "100,000 candidates — most completely irrelevant (accountants, civil engineers, etc.)",
    "Keyword matching fails: someone can list 'RAG, Pinecone, FAISS' as skills but be a marketing manager",
    "JD says '5-9 years' but means 'shipped a production ranking system at a product company'",
    "Ghost candidates: perfect profile, but haven't logged in for 6 months & 5% response rate",
    "~80 honeypots with subtly impossible profiles designed to trap naive keyword matchers",
    "The gap between what the JD says and what the JD MEANS is where ranking systems fail",
], 0.6, 1.7, 7.5, 4.8, size=15)

card(sl, 8.7, 1.7, 4.2, 4.8)
add_text(sl, "Key Insight", 8.9, 1.9, 3.8, 0.5, size=16, bold=True, color=ACCENT)
add_text(sl,
    "A Tier-5 candidate may not use the words 'RAG' or 'Pinecone' in their profile, "
    "but if their career history shows they built a recommendation system at a product company, "
    "they're a fit.\n\n"
    "A candidate who has all the AI keywords but whose title is 'Marketing Manager' "
    "is not a fit, no matter how perfect their skill list looks.",
    8.9, 2.5, 3.8, 3.8, size=13, color=WHITE)

sl.notes_slide.notes_text_frame.text = (
    "Talk about the trap: naive BM25 or embedding-only systems get fooled by keyword stuffers. "
    "The real challenge is semantic understanding of career trajectory + behavioral signals."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 3 — Existing Limitations
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Why Existing Approaches Fall Short", accent_color=RED)

for i, (icon, title, body) in enumerate([
    ("🔍", "Pure Keyword / BM25",
     "Fails on keyword stuffers. 'Expert in FAISS' with 0 months usage scores the same as a practitioner."),
    ("🧠", "Embedding-Only",
     "Dense similarity finds 'relevant text' but ignores career trajectory, company type, and availability."),
    ("📊", "Static Rules",
     "Hard thresholds (must have 5+ yrs Python) miss strong candidates and include gaming attempts."),
    ("👻", "Ignoring Behavioral Signals",
     "A 0.95-scoring candidate who is inactive + 5% response rate is, for hiring purposes, NOT available."),
]):
    row = i // 2; col = i % 2
    cx  = 0.5 + col * 6.4; cy = 1.7 + row * 2.55
    card(sl, cx, cy, 6.0, 2.3)
    add_text(sl, f"{icon}  {title}", cx+0.2, cy+0.15, 5.6, 0.55, size=16, bold=True, color=ACCENT2)
    add_text(sl, body, cx+0.2, cy+0.7, 5.6, 1.4, size=13, color=WHITE)

sl.notes_slide.notes_text_frame.text = (
    "This slide shows we understand the landscape. Each limitation maps directly to a design decision in our system."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 4 — Our Solution
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Our Solution: Multi-Signal Ranking", "7-component weighted scorer + behavioral multiplier")

steps = [
    ("Stage 0\nPre-filter", "Keyword scan\non raw JSONL\n→ 8K candidates\nin 12 sec", ACCENT),
    ("Stage 1\nFeature\nExtraction", "30+ features:\nskills, career,\nbehavior, edu,\nhoneypot", ACCENT2),
    ("Stage 2\nTF-IDF\nRetrieval", "Bigram TF-IDF\ncosine sim vs JD\n→ Top-500\n[FAISS-ready]", ACCENT3),
    ("Stage 3\nMulti-Signal\nScoring", "7 weighted\ncomponents\n→ composite\nscore", GOLD),
    ("Stage 4\nRule-Based\nRe-Ranking", "JD-specific\nboosts & penalties\n→ Top-100", RED),
    ("Stage 5\nExplain-\nability", "Fact-grounded\n1-2 sentence\nreasoning per\ncandidate", ACCENT),
]

for i, (step, desc, color) in enumerate(steps):
    x = 0.3 + i * 2.15
    card(sl, x, 1.8, 1.95, 4.5, fill=BG_CARD)
    bar = sl.shapes.add_shape(1, Inches(x), Inches(1.8), Inches(1.95), Inches(0.18))
    bar.fill.solid(); bar.fill.fore_color.rgb = color; bar.line.fill.background()
    add_text(sl, step,  x+0.08, 2.05, 1.8, 0.8, size=11, bold=True, color=color, align=PP_ALIGN.CENTER)
    add_text(sl, desc,  x+0.08, 2.85, 1.8, 3.0, size=11, color=WHITE, align=PP_ALIGN.CENTER)
    if i < 5:
        add_text(sl, "→", x+2.05, 3.7, 0.2, 0.4, size=18, bold=True, color=MUTED, align=PP_ALIGN.CENTER)

add_text(sl, "⚡  Total: 22 seconds on CPU · No network · No GPU · 100K candidates",
         0.5, 6.8, 12.3, 0.45, size=14, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)

sl.notes_slide.notes_text_frame.text = (
    "Walk through each stage. Emphasize the two-pass design: cheap pre-filter first, "
    "then expensive features only on likely candidates. This is how production systems work."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 5 — Candidate Understanding
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Candidate Understanding", "30+ features extracted per candidate")

left_items = [
    "✦  Skill proficiency × endorsements × duration_months",
    "✦  Target skill hit count (vs 40+ JD keywords)",
    "✦  Career ML fraction (% of career in ML/AI roles)",
    "✦  Shipped ranking / retrieval / recommendation system?",
    "✦  Product-company vs consulting fraction",
    "✦  Title progression score (junior → senior trajectory)",
    "✦  Job-hopping detection (jobs in last 3 years)",
]
right_items = [
    "✦  Last active days (ghost candidate detection)",
    "✦  Recruiter response rate & avg response time",
    "✦  Interview completion rate",
    "✦  GitHub activity score (0-100)",
    "✦  Notice period fit (sub-30d preferred)",
    "✦  Education tier (IIT/IISc=1 → tier4)",
    "✦  Honeypot detection (3 heuristics)",
]
add_bullet_box(sl, left_items,  0.5, 1.7, 6.2, 5.0, size=13)
add_bullet_box(sl, right_items, 7.0, 1.7, 6.0, 5.0, size=13)

sl.notes_slide.notes_text_frame.text = (
    "Each feature maps to a specific JD signal. Honeypot detection uses 3 heuristics: "
    "expert skills with 0 months usage, timeline impossibility, and inverted salary ranges."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 6 — Semantic Search
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Semantic Search & Retrieval", "TF-IDF now · FAISS + Sentence-Transformers drop-in ready")

card(sl, 0.5, 1.7, 5.8, 5.0)
add_text(sl, "Current: TF-IDF Retrieval", 0.7, 1.85, 5.4, 0.5, size=16, bold=True, color=ACCENT)
add_bullet_box(sl, [
    "Bigram TF-IDF (vocab ~20K) with sublinear TF",
    "JD text blob: 300+ word signal-rich query",
    "Cosine similarity on sparse matrix — O(N·V)",
    "Top-500 retrieved in milliseconds",
    "8,000-doc corpus fits in <500 MB RAM",
], 0.7, 2.4, 5.4, 3.9, size=13)

card(sl, 7.0, 1.7, 5.9, 5.0)
add_text(sl, "Upgrade: FAISS + Sentence Transformers", 7.2, 1.85, 5.5, 0.5, size=14, bold=True, color=ACCENT2)
add_bullet_box(sl, [
    "BAAI/bge-small-en-v1.5  →  dense 384-dim vectors",
    "FAISS IVFFlat index  →  sub-linear ANN search",
    "Cross-encoder re-ranker (ms-marco-MiniLM-L-6-v2)",
    "One-line swap in src/retrieval.py",
    "Same API surface — zero pipeline changes",
], 7.2, 2.4, 5.5, 3.9, size=13, color=WHITE)

add_text(sl, "→", 6.25, 4.0, 0.5, 0.6, size=30, bold=True, color=MUTED, align=PP_ALIGN.CENTER)
add_text(sl, "drop-in\nupgrade", 6.1, 4.65, 0.8, 0.7, size=10, color=MUTED, align=PP_ALIGN.CENTER)

sl.notes_slide.notes_text_frame.text = (
    "The architecture is deliberately FAISS-ready. The TF-IDF system meets all compute constraints "
    "and produces strong results. When sentence-transformers is available, it's a one-line swap."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 7 — Scoring & Re-ranking
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Multi-Signal Scoring & Re-Ranking", "7 components · behavioral multiplier · JD-specific filters")

weights = [
    ("Skill Match",    30, ACCENT,  "TF-IDF sim + skill coverage + proficiency weight"),
    ("Experience",     20, ACCENT2, "YOE (5-9 sweet spot) + product fraction + production ML"),
    ("Domain",         20, ACCENT3, "Shipped ranking/retrieval? ML title? ML career %?"),
    ("Career Growth",  10, GOLD,    "Title progression + tenure + anti-job-hopping"),
    ("Behavioral",     10, RED,     "Activity · response rate · interview rate · GitHub"),
    ("Location",        5, WHITE,   "Target cities or willing to relocate"),
    ("Education",       5, MUTED,   "Tier 1-4 institution + CS/STEM field"),
]
for i, (name, w, color, desc) in enumerate(weights):
    y = 1.7 + i * 0.73
    bar_w = w * 0.09
    bar = sl.shapes.add_shape(1, Inches(0.5), Inches(y+0.12), Inches(bar_w), Inches(0.42))
    bar.fill.solid(); bar.fill.fore_color.rgb = color; bar.line.fill.background()
    add_text(sl, f"{w}%", 0.5+bar_w+0.08, y+0.08, 0.5, 0.45, size=14, bold=True, color=color)
    add_text(sl, f"{name}  —  {desc}", 1.2, y+0.08, 8.4, 0.45, size=12, color=WHITE)

card(sl, 9.9, 1.7, 3.1, 5.2)
add_text(sl, "Re-Ranker Filters", 10.05, 1.85, 2.8, 0.5, size=14, bold=True, color=ACCENT3)
add_bullet_box(sl, [
    "Shipped ranking → ×1.08",
    "Product co. fraction → ×1.05",
    "Hard req. ML skill → ×1.10",
    "Consulting-only → ×0.40",
    "Inactive 6+ months → ×0.50",
    "Bad title → ×0.25",
    "Honeypot → excluded",
], 10.05, 2.4, 2.8, 4.2, size=12)

sl.notes_slide.notes_text_frame.text = (
    "The behavioral multiplier is key: final_score = weighted_sum × (0.5 + 0.5 × behavioral_score). "
    "This means a ghost candidate can never rank in the top 10, even with perfect skills."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 8 — Explainability
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Explainability Engine", "Fact-grounded, honest, varied — meets Stage 4 manual review criteria")

add_bullet_box(sl, [
    "References specific facts: title, YOE, company, named skills, signal values",
    "Connects to JD requirements (not generic praise)",
    "Honest concerns acknowledged: notice period, inactivity, consulting background",
    "No hallucination: only claims present in the candidate's actual profile",
    "Substantive variation: different phrasing per candidate, rank-appropriate tone",
], 0.5, 1.7, 12.3, 2.2, size=14)

examples = [
    ("#1 score=1.00", "Strong fit — Senior NLP Engineer with 7.8 years at Niramai; relevant skills: "
     "embeddings, faiss, feature engineering; shipped ranking/retrieval to production. "
     "Tier-1 institution adds confidence in technical depth.", ACCENT),
    ("#5 score=0.99", "Top pick — Applied ML Engineer with 6 years at Freshworks; relevant skills: "
     "faiss, kubeflow, mlops, opensearch; shipped recommendation system to production. "
     "Caveat: notice period 90d may delay start.", ACCENT2),
    ("#47 score=0.68", "Moderate fit — ML Engineer with 5.1 years; relevant skills: pytorch, nlp. "
     "Concern: consulting-heavy background (72% of career in IT services); "
     "notice period 120d may delay start.", GOLD),
]
for i, (label, text, color) in enumerate(examples):
    y = 3.75 + i * 1.12
    card(sl, 0.5, y, 12.3, 1.02)
    add_text(sl, label, 0.65, y+0.07, 1.5, 0.4, size=11, bold=True, color=color)
    add_text(sl, text,  2.2,  y+0.07, 10.4, 0.85, size=11.5, color=WHITE)

sl.notes_slide.notes_text_frame.text = (
    "Show that the reasoning varies by rank — rank 1 gets glowing, rank 47 gets honest concerns. "
    "This is exactly what Stage 4 manual review checks for."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 9 — Results
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Results", "Top-10 candidates are all genuine ML engineers with production AI experience")

metrics = [("Runtime", "22 sec", ACCENT), ("Candidates", "100K", ACCENT2),
           ("Honeypots\nDetected", "473", RED), ("Submission\nValidator", "✅ PASS", ACCENT)]
for i, (label, val, color) in enumerate(metrics):
    x = 0.5 + i * 3.2
    card(sl, x, 1.7, 2.9, 1.5)
    add_text(sl, val,   x+0.15, 1.82, 2.6, 0.7, size=28, bold=True, color=color, align=PP_ALIGN.CENTER)
    add_text(sl, label, x+0.15, 2.42, 2.6, 0.6, size=12, color=MUTED, align=PP_ALIGN.CENTER)

top10 = [
    (1, "CAND_0011687", "Senior NLP Engineer",    "Niramai",    7.8, "IIT Tier-1", "1.0000"),
    (2, "CAND_0061655", "ML Engineer",            "Krutrim",    4.6, "Tier-2",     "1.0000"),
    (3, "CAND_0077337", "Staff ML Engineer",      "Paytm",      7.0, "IIT Tier-1", "1.0000"),
    (4, "CAND_0081846", "Lead AI Engineer",       "Razorpay",   6.7, "IIT Tier-1", "1.0000"),
    (5, "CAND_0050876", "Applied ML Engineer",    "Freshworks", 6.0, "Tier-2",     "0.9992"),
]
headers = ["#", "Candidate ID", "Title", "Company", "YOE", "Education", "Score"]
col_w = [0.4, 1.6, 2.4, 1.6, 0.6, 1.4, 0.8]
xs = [0.5]
for w in col_w[:-1]: xs.append(xs[-1]+w)

header_bar = sl.shapes.add_shape(1, Inches(0.5), Inches(3.55), Inches(12.3), Inches(0.4))
header_bar.fill.solid(); header_bar.fill.fore_color.rgb = ACCENT; header_bar.line.fill.background()
for j, (h, x, w) in enumerate(zip(headers, xs, col_w)):
    add_text(sl, h, x+0.05, 3.57, w-0.1, 0.35, size=11, bold=True, color=BG_DARK, align=PP_ALIGN.LEFT)

for i, row in enumerate(top10):
    y = 3.98 + i * 0.56
    if i % 2 == 0:
        rb = sl.shapes.add_shape(1, Inches(0.5), Inches(y), Inches(12.3), Inches(0.54))
        rb.fill.solid(); rb.fill.fore_color.rgb = BG_CARD; rb.line.fill.background()
    for j, (val, x, w) in enumerate(zip(row, xs, col_w)):
        c = ACCENT if j == 6 else (ACCENT2 if j == 1 else WHITE)
        add_text(sl, str(val), x+0.05, y+0.08, w-0.1, 0.38, size=11, color=c)

sl.notes_slide.notes_text_frame.text = (
    "All top-10 candidates are genuine ML engineers with embeddings/retrieval/ranking experience. "
    "None are honeypots. All have shipped production ML systems. "
    "The behavioral multiplier ensures ghost candidates don't appear in top positions."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SLIDE 10 — Future Work
# ═══════════════════════════════════════════════════════════════════════════════
sl = blank_slide(); bg(sl)
slide_header(sl, "Future Work & Production Roadmap", accent_color=ACCENT3)

roadmap = [
    ("Dense Embeddings", "🧠",
     "Replace TF-IDF with BAAI/bge-small-en-v1.5 sentence transformers for true semantic matching. "
     "One-line swap in src/retrieval.py — architecture already supports it.",
     ACCENT2),
    ("Cross-Encoder Re-ranker", "⚡",
     "Use cross-encoder/ms-marco-MiniLM-L-6-v2 on top-200 candidates. "
     "Produces (JD, candidate) pair scores — 10× better than bi-encoder for re-ranking.",
     ACCENT3),
    ("Online Learning", "📈",
     "Collect recruiter click / response signals to fine-tune scoring weights via "
     "LambdaRank or ListNet. Close the offline-online gap.",
     GOLD),
    ("Local LLM Re-ranking", "🤖",
     "Use Mistral-7B or Llama-3-8B (quantized, CPU) on top-50 candidates for "
     "rich contextual reasoning — still within compute budget.",
     RED),
    ("A/B Evaluation Harness", "🔬",
     "Build recruiter-engagement A/B test framework. Track NDCG@10 vs "
     "actual interview-booked rate to validate offline metrics.",
     ACCENT),
    ("Graph Signals", "🕸",
     "Build candidate similarity graph to detect behavioral twins and "
     "cold-start candidates from social/professional network signals.",
     WHITE),
]

for i, (title, icon, desc, color) in enumerate(roadmap):
    row = i // 3; col = i % 3
    x = 0.4 + col * 4.3; y = 1.7 + row * 2.65
    card(sl, x, y, 4.0, 2.45)
    add_text(sl, f"{icon}  {title}", x+0.15, y+0.12, 3.7, 0.5, size=14, bold=True, color=color)
    add_text(sl, desc, x+0.15, y+0.65, 3.7, 1.65, size=11, color=WHITE)

add_text(sl,
    "The system is production-ready today. These improvements further close the gap "
    "between offline ranking quality and real-world recruiter outcomes.",
    0.5, 7.0, 12.3, 0.35, size=12, color=MUTED, align=PP_ALIGN.CENTER, italic=True)

sl.notes_slide.notes_text_frame.text = (
    "Close by emphasizing: we built something that works NOW and is designed to improve. "
    "The architecture choices (FAISS-ready, swappable embedder, modular scoring) mean "
    "each of these upgrades is a small diff, not a rewrite."
)

# ── Save ──────────────────────────────────────────────────────────────────────
os.makedirs("outputs", exist_ok=True)
prs.save("outputs/redrob_ranking_presentation.pptx")
print("✅  Presentation saved: outputs/redrob_ranking_presentation.pptx")
