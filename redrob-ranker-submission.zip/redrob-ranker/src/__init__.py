# redrob-ranker/src/__init__.py
"""
Redrob Hackathon — Intelligent Candidate Ranking System.
"""
