"""
src/candidate_parser.py
-----------------------
Converts a raw candidate JSON record into a structured feature dictionary
consumed by scoring.py, embeddings.py and explainability.py.

Connects to: data_loader.py → candidate_parser.py → scoring.py / embeddings.py
"""

import logging
import re
from datetime import date, datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Honeypot detection helpers
# ──────────────────────────────────────────────────────────────────────────────

_HONEYPOT_COMPANIES_FOUNDED = {
    # company_name_lower: earliest_plausible_start_year
    # (populated from the redrob_signals_doc; we use heuristics instead)
}

_EXPERT_SKILLS_WITH_ZERO_DURATION_THRESHOLD = 3


def _detect_honeypot(record: dict) -> bool:
    """
    Return True if the candidate looks like a honeypot.
    Two main signals:
    1. Expert-level skills claimed with 0 months of usage.
    2. start_date at current company pre-dates company founding (we approximate
       by checking if duration_months exceeds years_of_experience * 12 + 24).
    """
    skills = record.get("skills", [])
    expert_zero = sum(
        1 for s in skills
        if s.get("proficiency") == "expert" and s.get("duration_months", 1) == 0
    )
    if expert_zero >= _EXPERT_SKILLS_WITH_ZERO_DURATION_THRESHOLD:
        return True

    yoe        = record.get("profile", {}).get("years_of_experience", 0)
    career     = record.get("career_history", [])
    total_mos  = sum(c.get("duration_months", 0) for c in career)
    if total_mos > (yoe * 12 + 36) and yoe < 5:
        return True

    # salary range inverted (min > max by large margin)
    signals = record.get("redrob_signals", {})
    sal = signals.get("expected_salary_range_inr_lpa", {})
    if sal.get("min", 0) > sal.get("max", 1) * 1.5:
        return True

    return False


# ──────────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────────

TARGET_SKILLS = {
    # Hard-required (from JD)
    "embeddings", "vector search", "faiss", "pinecone", "weaviate", "qdrant",
    "milvus", "opensearch", "elasticsearch", "sentence transformers",
    "sentence-transformers", "information retrieval", "bm25",
    "ndcg", "mrr", "learning to rank", "ltr", "xgboost", "lightgbm",
    "python", "rag", "fine-tuning", "fine tuning", "lora", "peft", "qlora",
    "hugging face", "huggingface", "transformers", "nlp",
    "recommendation systems", "ranking",
    # Preferred
    "mlops", "mlflow", "kubeflow", "a/b testing", "evaluation framework",
    "pytorch", "tensorflow", "scikit-learn", "haystack", "langchain",
    "hybrid search", "feature engineering",
}

CONSULTING_COMPANIES = {
    "tcs", "infosys", "wipro", "accenture", "cognizant", "capgemini",
    "hcl", "tech mahindra", "mindtree", "mphasis",
}

PRODUCT_COMPANY_INDICATORS = {
    "swiggy", "zomato", "flipkart", "ola", "uber", "razorpay", "cred",
    "meesho", "paytm", "phonepe", "byju", "udaan", "dunzo", "zepto",
    "mad street den", "moengage", "freshworks", "zoho", "hasura",
    # generic markers
    "startup", "saas", "product",
}


def parse_candidate(record: dict) -> Dict[str, Any]:
    """
    Extract structured features from a raw candidate record.

    Returns a flat dict with all features needed for scoring and ranking.
    """
    profile   = record.get("profile", {})
    career    = record.get("career_history", [])
    education = record.get("education", [])
    skills    = record.get("skills", [])
    signals   = record.get("redrob_signals", {})

    is_honeypot = _detect_honeypot(record)

    # ── Skills ────────────────────────────────────────────────────────────────
    skill_names      = {s["name"].lower() for s in skills}
    skill_map        = {s["name"].lower(): s for s in skills}
    target_hit_names = skill_names & TARGET_SKILLS
    skill_score_raw  = _skill_score(skills, target_hit_names)

    # ── Career ────────────────────────────────────────────────────────────────
    total_months        = sum(c.get("duration_months", 0) for c in career)
    yoe                 = profile.get("years_of_experience", total_months / 12)
    consulting_fraction = _consulting_fraction(career)
    product_fraction    = _product_fraction(career)
    ml_ai_fraction      = _ml_ai_fraction(career)
    has_production_ml   = _has_production_ml(career)
    avg_tenure_months   = total_months / max(len(career), 1)
    job_count_3yr       = _jobs_in_last_n_years(career, 3)
    title_progression   = _title_progression_score(career)
    current_title_lower = profile.get("current_title", "").lower()
    is_ml_title         = _is_ml_title(current_title_lower)
    shipped_ranking     = _shipped_ranking_or_retrieval(career)

    # ── Education ─────────────────────────────────────────────────────────────
    edu_tier   = _best_edu_tier(education)
    is_cs_stem = _is_cs_stem(education)

    # ── Behavioral signals ────────────────────────────────────────────────────
    last_active_days = _days_since(signals.get("last_active_date"))
    is_active        = last_active_days is not None and last_active_days < 90
    open_to_work     = signals.get("open_to_work_flag", False)
    response_rate    = signals.get("recruiter_response_rate", 0.0)
    notice_days      = signals.get("notice_period_days", 90)
    github_score     = max(signals.get("github_activity_score", -1), 0)
    profile_complete = signals.get("profile_completeness_score", 0)
    interview_rate   = signals.get("interview_completion_rate", 0)
    saved_30d        = signals.get("saved_by_recruiters_30d", 0)
    salary_min       = signals.get("expected_salary_range_inr_lpa", {}).get("min", 0)
    salary_max       = signals.get("expected_salary_range_inr_lpa", {}).get("max", 999)
    skill_assessments= signals.get("skill_assessment_scores", {})
    avg_assessment   = (sum(skill_assessments.values()) / len(skill_assessments)
                        if skill_assessments else 0.0)
    location         = profile.get("location", "").lower()
    country          = profile.get("country", "").lower()
    willing_relocate = signals.get("willing_to_relocate", False)
    preferred_mode   = signals.get("preferred_work_mode", "flexible")

    # ── Location fit ──────────────────────────────────────────────────────────
    in_target_location = _in_target_location(location, country, willing_relocate)

    # ── Text blob (for TF-IDF matching) ───────────────────────────────────────
    text_blob = _build_candidate_text_blob(profile, career, skills, education)

    return {
        # Identity
        "candidate_id"          : record["candidate_id"],
        "name"                  : profile.get("anonymized_name", ""),
        "headline"              : profile.get("headline", ""),
        "location"              : location,
        "country"               : country,
        "current_title"         : profile.get("current_title", ""),
        "current_company"       : profile.get("current_company", ""),
        "current_company_size"  : profile.get("current_company_size", ""),
        # Skills
        "skill_names"           : list(skill_names),
        "target_skill_hits"     : list(target_hit_names),
        "num_target_skills"     : len(target_hit_names),
        "skill_score_raw"       : skill_score_raw,
        # Experience
        "years_of_experience"   : yoe,
        "total_career_months"   : total_months,
        "consulting_fraction"   : consulting_fraction,
        "product_fraction"      : product_fraction,
        "ml_ai_fraction"        : ml_ai_fraction,
        "has_production_ml"     : has_production_ml,
        "shipped_ranking"       : shipped_ranking,
        "avg_tenure_months"     : avg_tenure_months,
        "job_count_3yr"         : job_count_3yr,
        "title_progression"     : title_progression,
        "is_ml_title"           : is_ml_title,
        # Education
        "edu_tier"              : edu_tier,
        "is_cs_stem"            : is_cs_stem,
        # Behavioral
        "is_active"             : is_active,
        "last_active_days"      : last_active_days or 999,
        "open_to_work"          : open_to_work,
        "response_rate"         : response_rate,
        "notice_days"           : notice_days,
        "github_score"          : github_score,
        "profile_completeness"  : profile_complete,
        "interview_completion"  : interview_rate,
        "saved_by_recruiters"   : saved_30d,
        "avg_assessment_score"  : avg_assessment,
        "salary_min_lpa"        : salary_min,
        "salary_max_lpa"        : salary_max,
        "preferred_mode"        : preferred_mode,
        # Location
        "in_target_location"    : in_target_location,
        "willing_relocate"      : willing_relocate,
        # Honeypot
        "is_honeypot"           : is_honeypot,
        # Text for semantic matching
        "text_blob"             : text_blob,
        # Raw nested (for explainability)
        "career_history"        : career,
        "education"             : education,
        "skills_raw"            : skills,
    }


# ──────────────────────────────────────────────────────────────────────────────
# Private helpers
# ──────────────────────────────────────────────────────────────────────────────

def _skill_score(skills: List[dict], target_hits: set) -> float:
    """
    Weighted skill score:
    - proficiency weight: expert=1.0, advanced=0.8, intermediate=0.6, beginner=0.4
    - endorsement weight: log scale
    - duration weight: longer = more trustworthy
    Only counts target skills.
    """
    import math
    PROF_WEIGHT = {"expert": 1.0, "advanced": 0.8, "intermediate": 0.6, "beginner": 0.4}
    total = 0.0
    for s in skills:
        if s["name"].lower() not in target_hits:
            continue
        pw  = PROF_WEIGHT.get(s.get("proficiency", "beginner"), 0.4)
        ew  = math.log1p(s.get("endorsements", 0)) / math.log1p(60)
        dw  = min(s.get("duration_months", 0) / 36, 1.0)
        total += pw * (0.5 + 0.3 * ew + 0.2 * dw)
    return min(total, 10.0)


def _consulting_fraction(career: List[dict]) -> float:
    total = sum(c.get("duration_months", 0) for c in career)
    if total == 0:
        return 0.0
    cons = sum(
        c.get("duration_months", 0) for c in career
        if any(cc in c.get("company", "").lower() for cc in CONSULTING_COMPANIES)
    )
    return cons / total


def _product_fraction(career: List[dict]) -> float:
    """Fraction of career at product / startup companies."""
    total = sum(c.get("duration_months", 0) for c in career)
    if total == 0:
        return 0.0
    prod = sum(
        c.get("duration_months", 0) for c in career
        if (any(p in c.get("company", "").lower() for p in PRODUCT_COMPANY_INDICATORS)
            or c.get("company_size", "") in ("11-50", "51-200", "201-500", "501-1000"))
    )
    return min(prod / total, 1.0)


def _ml_ai_fraction(career: List[dict]) -> float:
    """Fraction of career in ML / AI / data-science roles."""
    total = sum(c.get("duration_months", 0) for c in career)
    if total == 0:
        return 0.0
    ml_keywords = {
        "machine learning", "ml engineer", "data scientist", "ai engineer",
        "nlp", "applied ml", "search engineer", "recommendation", "ranking",
        "retrieval", "applied ai", "research engineer",
    }
    ml = sum(
        c.get("duration_months", 0) for c in career
        if any(kw in c.get("title", "").lower() or kw in c.get("description", "").lower()
               for kw in ml_keywords)
    )
    return min(ml / total, 1.0)


def _has_production_ml(career: List[dict]) -> bool:
    prod_keywords = {
        "deployed", "production", "shipped", "ranking model",
        "retrieval system", "recommendation system", "embedding",
        "vector search", "search engine", "a/b test", "inference",
    }
    for c in career:
        desc = c.get("description", "").lower()
        if any(kw in desc for kw in prod_keywords):
            return True
    return False


def _shipped_ranking_or_retrieval(career: List[dict]) -> bool:
    keywords = {
        "ranking", "retrieval", "recommendation", "search engine",
        "vector search", "embedding", "information retrieval",
        "relevance", "discovery feed",
    }
    for c in career:
        title = c.get("title", "").lower()
        desc  = c.get("description", "").lower()
        if any(kw in title or kw in desc for kw in keywords):
            return True
    return False


def _best_edu_tier(education: List[dict]) -> int:
    """Return the best (lowest number = highest prestige) tier found. 1=IIT/IISc, 4=tier4."""
    tier_map = {"tier_1": 1, "tier_2": 2, "tier_3": 3, "tier_4": 4, "unknown": 4}
    tiers = [tier_map.get(e.get("tier", "unknown"), 4) for e in education]
    return min(tiers) if tiers else 4


def _is_cs_stem(education: List[dict]) -> bool:
    cs_keywords = {
        "computer science", "computer engineering", "information technology",
        "software", "machine learning", "data science", "artificial intelligence",
        "mathematics", "statistics", "electrical engineering",
    }
    for e in education:
        fos = e.get("field_of_study", "").lower()
        if any(kw in fos for kw in cs_keywords):
            return True
    return False


def _days_since(date_str: Optional[str]) -> Optional[int]:
    if not date_str:
        return None
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        return (date.today() - d).days
    except ValueError:
        return None


def _is_ml_title(title: str) -> bool:
    ml_titles = {
        "ml engineer", "ai engineer", "machine learning", "data scientist",
        "nlp engineer", "search engineer", "recommendation", "applied ml",
        "applied ai", "ranking engineer", "research engineer",
    }
    return any(kw in title for kw in ml_titles)


def _jobs_in_last_n_years(career: List[dict], n: int) -> int:
    today    = date.today()
    cutoff   = today.replace(year=today.year - n)
    count    = 0
    for c in career:
        try:
            sd = datetime.strptime(c.get("start_date", "2000-01-01"), "%Y-%m-%d").date()
            if sd >= cutoff:
                count += 1
        except ValueError:
            pass
    return count


def _title_progression_score(career: List[dict]) -> float:
    """
    Simple heuristic: did titles get more senior over time?
    Returns 0.0 – 1.0.
    """
    SENIORITY = {
        "intern": 0, "junior": 1, "associate": 1, "analyst": 1,
        "engineer": 2, "developer": 2, "scientist": 2,
        "senior": 3, "lead": 3, "principal": 4, "staff": 4,
        "manager": 3, "architect": 4, "director": 5, "vp": 5, "head": 5,
    }
    scored = []
    for c in sorted(career, key=lambda x: x.get("start_date", "0000")):
        title  = c.get("title", "").lower()
        scores = [v for k, v in SENIORITY.items() if k in title]
        scored.append(max(scores) if scores else 2)
    if len(scored) < 2:
        return 0.5
    improving = sum(1 for a, b in zip(scored, scored[1:]) if b >= a)
    return improving / max(len(scored) - 1, 1)


def _in_target_location(location: str, country: str, willing_relocate: bool) -> bool:
    TARGET_LOCS = {"pune", "noida", "hyderabad", "bangalore", "mumbai",
                   "delhi", "gurgaon", "india"}
    if any(tl in location for tl in TARGET_LOCS) or country == "india":
        return True
    return willing_relocate


def _build_candidate_text_blob(
    profile: dict,
    career: List[dict],
    skills: List[dict],
    education: List[dict],
) -> str:
    """Build a rich text blob for TF-IDF / semantic matching."""
    parts = []
    parts.append(profile.get("headline", ""))
    parts.append(profile.get("summary", ""))
    parts.append(profile.get("current_title", ""))
    for c in career:
        parts.append(c.get("title", ""))
        parts.append(c.get("description", ""))
    for s in skills:
        parts.append(s.get("name", ""))
    for e in education:
        parts.append(e.get("field_of_study", ""))
        parts.append(e.get("degree", ""))
    return " ".join(p for p in parts if p)
