"""
src/data_loader.py
------------------
Responsible for loading, validating, and streaming candidate profiles
from a .jsonl or .jsonl.gz file.

Connects to: candidate_parser.py, app.py
"""

import gzip
import json
import logging
import re
from pathlib import Path
from typing import Generator, List, Optional

import pandas as pd

logger = logging.getLogger(__name__)


CANDIDATE_ID_PATTERN = re.compile(r"^CAND_[0-9]{7}$")

REQUIRED_TOP_LEVEL_KEYS = {
    "candidate_id", "profile", "career_history", "education",
    "skills", "redrob_signals"
}


def _validate_candidate(record: dict, line_num: int) -> bool:
    """Light schema validation; logs warnings on bad records."""
    missing = REQUIRED_TOP_LEVEL_KEYS - set(record.keys())
    if missing:
        logger.warning("Line %d: missing keys %s – skipping", line_num, missing)
        return False
    cid = record.get("candidate_id", "")
    if not CANDIDATE_ID_PATTERN.match(cid):
        logger.warning("Line %d: bad candidate_id '%s' – skipping", line_num, cid)
        return False
    return True


def stream_candidates(
    filepath: str | Path,
    max_records: Optional[int] = None,
    validate: bool = True,
) -> Generator[dict, None, None]:
    """
    Lazily stream candidate records from a .jsonl or .jsonl.gz file.

    Parameters
    ----------
    filepath : path to candidates.jsonl or candidates.jsonl.gz
    max_records : stop after this many *valid* records (None = all)
    validate : run schema validation (set False for speed in production)

    Yields
    ------
    dict – one raw candidate record
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Candidates file not found: {path}")

    opener = gzip.open if path.suffix == ".gz" else open
    mode   = "rt" if path.suffix == ".gz" else "r"

    logger.info("Opening %s …", path)
    valid_count = 0
    total_count = 0

    with opener(path, mode, encoding="utf-8") as fh:
        for line_num, raw_line in enumerate(fh, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            total_count += 1
            try:
                record = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                logger.warning("Line %d: JSON parse error – %s", line_num, exc)
                continue

            if validate and not _validate_candidate(record, line_num):
                continue

            yield record
            valid_count += 1

            if max_records is not None and valid_count >= max_records:
                logger.info("Reached max_records=%d – stopping early.", max_records)
                break

    logger.info("Loaded %d/%d valid records from %s", valid_count, total_count, path)


def load_candidates_list(
    filepath: str | Path,
    max_records: Optional[int] = None,
) -> List[dict]:
    """Load all candidates into memory as a list."""
    return list(stream_candidates(filepath, max_records=max_records))


def load_candidates_dataframe(
    filepath: str | Path,
    max_records: Optional[int] = None,
) -> pd.DataFrame:
    """
    Load candidates into a flat DataFrame (profile-level columns only).
    Nested fields (skills, career_history, etc.) are preserved as objects.
    """
    records = load_candidates_list(filepath, max_records=max_records)
    rows = []
    for r in records:
        flat = {"candidate_id": r["candidate_id"]}
        flat.update(r.get("profile", {}))
        flat["career_history"]  = r.get("career_history", [])
        flat["education"]       = r.get("education", [])
        flat["skills"]          = r.get("skills", [])
        flat["certifications"]  = r.get("certifications", [])
        flat["redrob_signals"]  = r.get("redrob_signals", {})
        rows.append(flat)

    df = pd.DataFrame(rows)
    logger.info("DataFrame shape: %s", df.shape)
    return df
