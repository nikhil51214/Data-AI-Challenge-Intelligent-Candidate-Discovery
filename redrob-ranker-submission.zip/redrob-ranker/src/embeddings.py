"""
src/embeddings.py
-----------------
Generates text representations and similarity scores for candidates vs JD.

Architecture:
  - Primary: TF-IDF + cosine similarity (fast, CPU, no network, meets compute budget)
  - Drop-in replacement: sentence-transformers / FAISS when available
  - Batch-efficient: vectorises all candidates in one shot

Connects to: candidate_parser.py → embeddings.py → retrieval.py
"""

from __future__ import annotations

import logging
import time
from typing import List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# TF-IDF Embedder (primary — CPU-only, no network)
# ──────────────────────────────────────────────────────────────────────────────

class TFIDFEmbedder:
    """
    Wraps sklearn TfidfVectorizer. Fit on all candidate blobs, then
    transform JD blob and each candidate blob to obtain cosine-similarity
    scores.

    Parameters
    ----------
    max_features : vocabulary cap (50 K gives good coverage in <1 s)
    ngram_range  : (1, 2) captures bigrams like "vector search", "fine tuning"
    """

    def __init__(
        self,
        max_features: int = 50_000,
        ngram_range: Tuple[int, int] = (1, 2),
    ) -> None:
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            sublinear_tf=True,          # log-scale TF
            min_df=1,
            max_df=0.95,
            strip_accents="unicode",
            analyzer="word",
        )
        self._fitted         = False
        self._candidate_matrix: csr_matrix | None = None
        self._candidate_ids:    List[str]          = []

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, texts: List[str], candidate_ids: List[str]) -> "TFIDFEmbedder":
        """
        Fit the vectoriser on a corpus of candidate text blobs.

        Parameters
        ----------
        texts         : list of text blobs (one per candidate)
        candidate_ids : parallel list of candidate IDs
        """
        assert len(texts) == len(candidate_ids), "texts and ids must be same length"
        t0 = time.time()
        logger.info("Fitting TF-IDF on %d documents …", len(texts))
        self._candidate_matrix = self.vectorizer.fit_transform(texts)
        self._candidate_ids    = list(candidate_ids)
        self._fitted           = True
        logger.info("TF-IDF fit complete in %.1f s  vocab=%d",
                    time.time() - t0, len(self.vectorizer.vocabulary_))
        return self

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query(
        self,
        jd_text: str,
        top_k: int = 200,
    ) -> Tuple[List[str], np.ndarray]:
        """
        Compute cosine similarity between JD and all candidates.

        Returns
        -------
        (candidate_ids_sorted, similarity_scores_sorted)
        Both sorted descending by similarity. Length = top_k.
        """
        if not self._fitted:
            raise RuntimeError("Call fit() before query().")

        jd_vec   = self.vectorizer.transform([jd_text])       # (1, vocab)
        sims     = cosine_similarity(jd_vec, self._candidate_matrix).ravel()  # (N,)

        # top-k
        top_idx  = np.argpartition(sims, -min(top_k, len(sims)))[-top_k:]
        top_idx  = top_idx[np.argsort(sims[top_idx])[::-1]]

        ids      = [self._candidate_ids[i] for i in top_idx]
        scores   = sims[top_idx]
        return ids, scores

    # ------------------------------------------------------------------
    # Bulk transform (for downstream re-use)
    # ------------------------------------------------------------------

    def transform(self, texts: List[str]) -> np.ndarray:
        """Return dense TF-IDF vectors for a list of texts."""
        if not self._fitted:
            raise RuntimeError("Call fit() before transform().")
        return self.vectorizer.transform(texts).toarray()

    @property
    def vocabulary_size(self) -> int:
        return len(self.vectorizer.vocabulary_) if self._fitted else 0


# ──────────────────────────────────────────────────────────────────────────────
# Sentence-Transformer Embedder (optional drop-in when available)
# ──────────────────────────────────────────────────────────────────────────────

class SentenceTransformerEmbedder:
    """
    Drop-in replacement for TFIDFEmbedder using sentence-transformers.
    Only available when `sentence_transformers` package is installed.

    Usage is identical to TFIDFEmbedder – call fit() then query().
    """

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(model_name)
            logger.info("SentenceTransformer loaded: %s", model_name)
        except ImportError:
            raise ImportError(
                "sentence-transformers not installed. "
                "pip install sentence-transformers  or use TFIDFEmbedder instead."
            )
        self._embeddings:     np.ndarray | None = None
        self._candidate_ids:  List[str]         = []

    def fit(self, texts: List[str], candidate_ids: List[str]) -> "SentenceTransformerEmbedder":
        logger.info("Encoding %d candidates with SentenceTransformer …", len(texts))
        t0 = time.time()
        self._embeddings    = self.model.encode(
            texts, batch_size=64, show_progress_bar=True, convert_to_numpy=True
        )
        self._candidate_ids = list(candidate_ids)
        logger.info("Encoding done in %.1f s", time.time() - t0)
        return self

    def query(
        self,
        jd_text: str,
        top_k: int = 200,
    ) -> Tuple[List[str], np.ndarray]:
        if self._embeddings is None:
            raise RuntimeError("Call fit() before query().")
        jd_emb = self.model.encode([jd_text], convert_to_numpy=True)
        sims   = cosine_similarity(jd_emb, self._embeddings).ravel()
        top_idx = np.argpartition(sims, -min(top_k, len(sims)))[-top_k:]
        top_idx = top_idx[np.argsort(sims[top_idx])[::-1]]
        ids     = [self._candidate_ids[i] for i in top_idx]
        return ids, sims[top_idx]


# ──────────────────────────────────────────────────────────────────────────────
# Factory helper
# ──────────────────────────────────────────────────────────────────────────────

def build_embedder(prefer_sentence_transformers: bool = False) -> TFIDFEmbedder:
    """Return the best available embedder."""
    if prefer_sentence_transformers:
        try:
            return SentenceTransformerEmbedder()
        except ImportError:
            logger.warning("sentence-transformers unavailable; falling back to TF-IDF.")
    logger.info("Using TF-IDF embedder.")
    return TFIDFEmbedder()
