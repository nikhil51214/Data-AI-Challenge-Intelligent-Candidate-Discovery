"""
src/evaluation.py
-----------------
Evaluation metrics for ranking quality:
  - Precision@K
  - Recall@K
  - NDCG@K  (Normalized Discounted Cumulative Gain)
  - MAP      (Mean Average Precision)
  - Ranking quality report

These metrics align exactly with what the hackathon judges compute:
  Final composite = 0.50 × NDCG@10 + 0.30 × NDCG@50 + 0.15 × MAP + 0.05 × P@10

Usage:
  - In development: call against a held-out labeled subset
  - In competition: scores computed by judges on hidden ground truth

Connects to: scoring.py → evaluation.py  (optional, for offline benchmarks)
"""

from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Core metric functions
# ──────────────────────────────────────────────────────────────────────────────

def precision_at_k(
    ranked_ids: Sequence[str],
    relevant_ids: set,
    k: int,
) -> float:
    """
    Fraction of top-K ranked items that are relevant.

    Parameters
    ----------
    ranked_ids   : ordered list of candidate IDs (rank 1 first)
    relevant_ids : set of known-relevant candidate IDs
    k            : cutoff

    Returns
    -------
    float in [0, 1]
    """
    top_k = list(ranked_ids)[:k]
    hits  = sum(1 for cid in top_k if cid in relevant_ids)
    return hits / k if k > 0 else 0.0


def recall_at_k(
    ranked_ids: Sequence[str],
    relevant_ids: set,
    k: int,
) -> float:
    """
    Fraction of all relevant items found in top-K.
    """
    top_k = list(ranked_ids)[:k]
    hits  = sum(1 for cid in top_k if cid in relevant_ids)
    denom = len(relevant_ids)
    return hits / denom if denom > 0 else 0.0


def dcg_at_k(
    ranked_ids: Sequence[str],
    relevance: Dict[str, float],
    k: int,
) -> float:
    """
    Discounted Cumulative Gain @ K.

    Parameters
    ----------
    ranked_ids : ordered IDs (rank 1 first)
    relevance  : {candidate_id: relevance_grade}  (e.g. 0, 1, 2, 3)
    k          : cutoff
    """
    dcg = 0.0
    for i, cid in enumerate(list(ranked_ids)[:k], start=1):
        rel  = relevance.get(cid, 0.0)
        dcg += (2 ** rel - 1) / math.log2(i + 1)
    return dcg


def ndcg_at_k(
    ranked_ids: Sequence[str],
    relevance: Dict[str, float],
    k: int,
) -> float:
    """
    Normalized DCG @ K.

    Returns
    -------
    float in [0, 1]
    """
    ideal_ids = sorted(relevance.keys(), key=lambda x: relevance[x], reverse=True)
    ideal_dcg = dcg_at_k(ideal_ids, relevance, k)
    if ideal_dcg == 0:
        return 0.0
    return dcg_at_k(ranked_ids, relevance, k) / ideal_dcg


def average_precision(
    ranked_ids: Sequence[str],
    relevant_ids: set,
) -> float:
    """
    Average Precision for a single query.
    AP = (1/R) * sum_k [ P@k * rel(k) ]  where R = |relevant|
    """
    if not relevant_ids:
        return 0.0
    hits   = 0
    ap_sum = 0.0
    for i, cid in enumerate(ranked_ids, start=1):
        if cid in relevant_ids:
            hits   += 1
            ap_sum += hits / i
    return ap_sum / len(relevant_ids)


def mean_average_precision(
    ranked_ids_list: List[Sequence[str]],
    relevant_ids_list: List[set],
) -> float:
    """MAP over multiple queries."""
    if not ranked_ids_list:
        return 0.0
    aps = [
        average_precision(r, rel)
        for r, rel in zip(ranked_ids_list, relevant_ids_list)
    ]
    return sum(aps) / len(aps)


# ──────────────────────────────────────────────────────────────────────────────
# Hackathon composite metric
# ──────────────────────────────────────────────────────────────────────────────

def hackathon_composite(
    ranked_ids: Sequence[str],
    relevance: Dict[str, float],
    relevant_ids: Optional[set] = None,
) -> Dict[str, float]:
    """
    Compute all hackathon metrics and the official composite score.

    Parameters
    ----------
    ranked_ids   : top-100 ranked candidate IDs (rank 1 first)
    relevance    : {candidate_id: grade}  (grade 0–3 or 0/1)
    relevant_ids : set of "relevant" IDs for P@K / Recall (defaults to grade > 0)

    Returns
    -------
    dict with ndcg10, ndcg50, map, p10, composite
    """
    if relevant_ids is None:
        relevant_ids = {cid for cid, g in relevance.items() if g > 0}

    ndcg10 = ndcg_at_k(ranked_ids, relevance, k=10)
    ndcg50 = ndcg_at_k(ranked_ids, relevance, k=50)
    map_   = average_precision(ranked_ids, relevant_ids)
    p10    = precision_at_k(ranked_ids, relevant_ids, k=10)
    p5     = precision_at_k(ranked_ids, relevant_ids, k=5)

    composite = 0.50 * ndcg10 + 0.30 * ndcg50 + 0.15 * map_ + 0.05 * p10

    results = {
        "NDCG@10"  : round(ndcg10,     4),
        "NDCG@50"  : round(ndcg50,     4),
        "MAP"      : round(map_,        4),
        "P@5"      : round(p5,          4),
        "P@10"     : round(p10,         4),
        "Composite": round(composite,   4),
    }
    logger.info("Evaluation results: %s", results)
    return results


# ──────────────────────────────────────────────────────────────────────────────
# Self-evaluation proxy (no ground truth needed)
# ──────────────────────────────────────────────────────────────────────────────

def self_evaluate(ranked_items: List[Dict]) -> Dict[str, float]:
    """
    Proxy evaluation when ground truth is unavailable.
    Uses our own score as a proxy for relevance grade (0–3).
    Useful for sanity-checking the ranking pipeline.
    """
    all_ids  = [it["candidate_id"] for it in ranked_items]
    # Bin scores into 0-3 grades
    relevance = {}
    for it in ranked_items:
        s = it.get("reranked_score", it.get("final_score", 0))
        if s > 0.50:
            g = 3
        elif s > 0.35:
            g = 2
        elif s > 0.20:
            g = 1
        else:
            g = 0
        relevance[it["candidate_id"]] = g

    top100_ids = all_ids[:100]
    return hackathon_composite(top100_ids, relevance)
