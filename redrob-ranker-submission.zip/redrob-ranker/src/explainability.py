"""
src/explainability.py
---------------------
Generates concise, fact-grounded 1-2 sentence reasoning for each ranked
candidate.  Reasoning references specific profile facts (years of
experience, named skills, current title, signal values) and connects
them to JD requirements.

Design:
- Template-free: reasoning is assembled from actual feature values
- Honest: includes concerns / gaps for lower-ranked candidates
- Variation: different phrasing per candidate (no copy-paste templates)

Connects to: scoring.py → explainability.py → output_generator.py
"""

from __future__ import annotations

import random
from typing import Any, Dict, List

# Seed for reproducibility (but still yields varied phrasing per candidate)
random.seed(42)


# ──────────────────────────────────────────────────────────────────────────────
# Phrasing pools (for variation)
# ──────────────────────────────────────────────────────────────────────────────

_STRENGTH_OPENERS = [
    "Strong fit:",
    "Good match:",
    "Relevant background:",
    "Solid profile:",
    "Well-aligned:",
    "Promising candidate:",
]

_CONCERN_CONNECTORS = [
    "Concern:",
    "Caveat:",
    "Note:",
    "Limitation:",
    "Flag:",
    "Gap:",
]


def _opener(rank: int) -> str:
    if rank <= 10:
        return random.choice(["Top pick —", "Strong fit —", "Excellent match —"])
    elif rank <= 30:
        return random.choice(["Good match —", "Solid candidate —", "Relevant profile —"])
    elif rank <= 60:
        return random.choice(["Moderate fit —", "Partial match —", "Worth considering —"])
    else:
        return random.choice(["Limited fit —", "Adjacent skills only —", "Below ideal threshold —"])


def _format_skill_list(skills: List[str], max_n: int = 4) -> str:
    if not skills:
        return "no directly relevant skills"
    shown  = skills[:max_n]
    others = len(skills) - max_n
    txt    = ", ".join(shown)
    if others > 0:
        txt += f" (+{others} more)"
    return txt


def generate_reasoning(item: Dict[str, Any]) -> str:
    """
    Generate a 1-2 sentence reasoning string for a ranked candidate.

    Parameters
    ----------
    item : one element from reranker output (has 'feat', 'components', 'rank', etc.)

    Returns
    -------
    str : 1-2 sentence reasoning
    """
    feat   = item.get("feat", {})
    comps  = item.get("components", {})
    rank   = item.get("rank", 99)
    score  = item.get("reranked_score", 0.0)

    cid    = feat.get("candidate_id", "")
    title  = feat.get("current_title", "unknown title")
    co     = feat.get("current_company", "unknown company")
    yoe    = feat.get("years_of_experience", 0)
    hits   = feat.get("target_skill_hits", [])
    loc    = feat.get("location", "")
    notice = feat.get("notice_days", 90)
    prod   = feat.get("has_production_ml", False)
    shipped= feat.get("shipped_ranking", False)
    active = feat.get("last_active_days", 999)
    resp   = feat.get("response_rate", 0.0)
    gh     = feat.get("github_score", 0)
    cons_f = feat.get("consulting_fraction", 0.0)
    is_ml  = feat.get("is_ml_title", False)
    ml_f   = feat.get("ml_ai_fraction", 0.0)
    ed_tier= feat.get("edu_tier", 4)

    # ── Part 1: strengths ─────────────────────────────────────────────────────
    parts = []

    # Title / YOE
    yoe_str = f"{yoe:.0f}" if yoe == int(yoe) else f"{yoe:.1f}"
    parts.append(f"{title} with {yoe_str} years of experience at {co}")

    # Key skills
    if hits:
        skill_str = _format_skill_list(sorted(hits)[:5])
        parts.append(f"directly relevant skills: {skill_str}")

    # Production ML / shipped ranking
    if shipped:
        parts.append("has shipped a ranking/retrieval/recommendation system to production")
    elif prod:
        parts.append("has production ML deployment experience")

    # ML title
    if is_ml and ml_f > 0.5:
        parts.append(f"career substantially in ML/AI roles ({ml_f*100:.0f}% of career)")

    # Location
    if feat.get("in_target_location", False):
        parts.append(f"located in target region ({loc})")
    elif feat.get("willing_relocate", False):
        parts.append("willing to relocate to target location")

    # Activity
    if active < 14:
        parts.append("actively engaged on platform (last active <2 weeks ago)")
    elif active < 60:
        parts.append("recently active on platform")

    # GitHub
    if gh > 50:
        parts.append(f"high GitHub activity (score {gh:.0f}/100)")

    sentence_1 = _opener(rank) + " " + "; ".join(parts[:3]) + "."

    # ── Part 2: concerns / qualifications ─────────────────────────────────────
    concerns = []

    if cons_f > 0.6:
        concerns.append(
            f"consulting-heavy background ({cons_f*100:.0f}% of career in IT services)"
        )
    if notice > 60:
        concerns.append(f"notice period {notice}d may delay start")
    if active > 120:
        concerns.append(f"inactive for {active}d — availability uncertain")
    if resp < 0.2:
        concerns.append(f"low recruiter response rate ({resp*100:.0f}%) — engagement risk")
    if yoe < 5:
        concerns.append(f"below preferred experience floor (JD asks 5–9 yrs, has {yoe_str} yrs)")
    if yoe > 12 and not is_ml:
        concerns.append("over-experienced for IC role without clear ML track")
    if not feat.get("is_cs_stem", True):
        concerns.append("non-CS/STEM educational background")
    if not hits:
        concerns.append("no directly matched JD skills found in profile")

    if concerns:
        c_str      = "; ".join(concerns[:2])
        connector  = random.choice(_CONCERN_CONNECTORS)
        sentence_2 = f"{connector} {c_str}."
        return f"{sentence_1} {sentence_2}"

    # No concerns: add a positive reinforcement
    if ed_tier == 1:
        sentence_2 = "Tier-1 institution background adds confidence in technical depth."
    elif score > 0.70:
        sentence_2 = "Overall profile is a strong match for this founding-team AI engineering role."
    else:
        sentence_2 = "Profile shows meaningful overlap with JD requirements."

    return f"{sentence_1} {sentence_2}"


def generate_all_reasonings(ranked_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Add 'reasoning' field to every item in the ranked list.

    Returns
    -------
    Same list with 'reasoning' populated in-place (also returned for chaining).
    """
    for item in ranked_items:
        item["reasoning"] = generate_reasoning(item)
    return ranked_items
