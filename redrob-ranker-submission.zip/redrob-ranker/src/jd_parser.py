"""
src/jd_parser.py
----------------
Converts a raw job description string into a structured JSON object.
Extracts: required skills, preferred skills, experience range, location,
disqualifiers, role keywords, and a combined text blob for embedding.

Connects to: embeddings.py, scoring.py, app.py
"""

import json
import logging
import re
from dataclasses import dataclass, field, asdict
from typing import List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Keyword banks
# ---------------------------------------------------------------------------

CORE_SKILLS_KEYWORDS = [
    # Embeddings / retrieval
    "embeddings", "sentence-transformers", "sentence transformers", "openai embeddings",
    "bge", "e5", "instructor", "text-embedding",
    # Vector DBs
    "faiss", "pinecone", "weaviate", "qdrant", "milvus", "opensearch",
    "elasticsearch", "vector search", "vector database", "hybrid search",
    # Ranking / retrieval
    "bm25", "learning to rank", "ltr", "xgboost", "lightgbm",
    "ndcg", "mrr", "map", "information retrieval",
    # LLMs
    "llm", "fine-tuning", "fine tuning", "lora", "qlora", "peft",
    "rag", "retrieval augmented", "langchain", "llama", "gpt", "claude",
    "hugging face", "huggingface", "transformers",
    # ML
    "nlp", "natural language processing", "recommendation systems",
    "ranking", "retrieval", "pytorch", "tensorflow", "scikit-learn",
    "mlops", "a/b testing", "a/b test", "evaluation framework",
    # Python
    "python",
]

PREFERRED_SKILLS_KEYWORDS = [
    "distributed systems", "large-scale inference", "open-source", "open source",
    "hr-tech", "recruiting tech", "marketplace", "kafka", "spark",
    "kubernetes", "docker", "mlflow", "kubeflow", "ray",
]

DISQUALIFIER_PATTERNS = [
    r"pure research",
    r"consulting firms?",
    r"computer vision",
    r"speech",
    r"robotics",
    r"title.chaser",
    r"framework enthusiast",
    r"closed.source proprietary",
    r"tcs|infosys|wipro|accenture|cognizant|capgemini",
]

# Locations explicitly mentioned in the JD
TARGET_LOCATIONS = ["pune", "noida", "hyderabad", "bangalore", "mumbai",
                    "delhi", "delhi ncr", "gurgaon"]


@dataclass
class ParsedJD:
    title: str                          = ""
    company: str                        = ""
    required_skills: List[str]          = field(default_factory=list)
    preferred_skills: List[str]         = field(default_factory=list)
    experience_min_years: int           = 5
    experience_max_years: int           = 9
    target_locations: List[str]         = field(default_factory=list)
    disqualifier_patterns: List[str]    = field(default_factory=list)
    role_type: str                      = "applied_ml"
    seniority: str                      = "senior"
    product_company_required: bool      = True
    production_required: bool           = True
    notice_period_preferred_days: int   = 30
    text_blob: str                      = ""      # used for TF-IDF / embedding

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


def parse_jd(jd_text: str) -> ParsedJD:
    """
    Parse a raw job description string into a structured ParsedJD object.

    Parameters
    ----------
    jd_text : raw JD text (markdown or plain text)

    Returns
    -------
    ParsedJD dataclass
    """
    text_lower = jd_text.lower()

    # --- title / company ---
    title   = _extract_between(jd_text, "Job Description:", "\n") or "Senior AI Engineer"
    company = _extract_between(jd_text, "Company:", "\n") or "Redrob AI"

    # --- required skills ---
    required_skills = [
        kw for kw in CORE_SKILLS_KEYWORDS
        if re.search(r'\b' + re.escape(kw) + r'\b', text_lower)
    ]

    # --- preferred skills ---
    preferred_skills = [
        kw for kw in PREFERRED_SKILLS_KEYWORDS
        if re.search(r'\b' + re.escape(kw) + r'\b', text_lower)
    ]

    # --- experience range ---
    exp_match = re.search(r'(\d+)[–\-–—](\d+)\s*years?', jd_text, re.IGNORECASE)
    exp_min   = int(exp_match.group(1)) if exp_match else 5
    exp_max   = int(exp_match.group(2)) if exp_match else 9

    # --- locations ---
    target_locs = [loc for loc in TARGET_LOCATIONS if loc in text_lower]

    # --- disqualifiers ---
    disqualifiers = [
        p for p in DISQUALIFIER_PATTERNS
        if re.search(p, text_lower)
    ]

    # --- notice period ---
    notice_match = re.search(r'sub.?(\d+).day notice', text_lower)
    notice_preferred = int(notice_match.group(1)) if notice_match else 30

    # --- text blob for embedding (cherry-pick key phrases) ---
    text_blob = _build_text_blob(jd_text, required_skills, preferred_skills)

    pjd = ParsedJD(
        title                        = title.strip(),
        company                      = company.strip(),
        required_skills              = required_skills,
        preferred_skills             = preferred_skills,
        experience_min_years         = exp_min,
        experience_max_years         = exp_max,
        target_locations             = target_locs,
        disqualifier_patterns        = disqualifiers,
        role_type                    = "applied_ml",
        seniority                    = "senior",
        product_company_required     = True,
        production_required          = True,
        notice_period_preferred_days = notice_preferred,
        text_blob                    = text_blob,
    )
    logger.info("JD parsed: %d required skills, %d preferred, exp %d–%d yrs",
                len(required_skills), len(preferred_skills), exp_min, exp_max)
    return pjd


def _extract_between(text: str, start: str, end: str) -> Optional[str]:
    idx = text.find(start)
    if idx == -1:
        return None
    idx += len(start)
    end_idx = text.find(end, idx)
    if end_idx == -1:
        return text[idx:].strip()
    return text[idx:end_idx].strip()


def _build_text_blob(
    raw_text: str,
    required_skills: List[str],
    preferred_skills: List[str],
) -> str:
    """Build a concise, signal-rich text blob for TF-IDF / semantic matching."""
    blob_parts = [
        "Senior AI Engineer applied machine learning production ranking retrieval "
        "embeddings vector search hybrid search information retrieval NLP "
        "evaluation framework NDCG MRR A/B testing product company Python "
        "sentence transformers FAISS pinecone weaviate qdrant elasticsearch opensearch "
        "fine-tuning LLM LoRA PEFT learning to rank recommendation systems "
        "ship production deploy inference latency quality",
    ]
    blob_parts.append(" ".join(required_skills))
    blob_parts.append(" ".join(preferred_skills))
    # Add key JD sentences verbatim
    for line in raw_text.split("\n"):
        if any(kw in line.lower() for kw in
               ["embedding", "retrieval", "ranking", "vector", "evaluation",
                "ndcg", "fine-tun", "production", "ship"]):
            blob_parts.append(line.strip())
    return " ".join(blob_parts)


# ---------------------------------------------------------------------------
# Built-in JD constant (from the hackathon bundle)
# ---------------------------------------------------------------------------

JD_TEXT = """
Job Description: Senior AI Engineer — Founding Team

Company: Redrob AI (Series A AI-native talent intelligence platform)
Location: Pune/Noida, India (Hybrid) | Open to relocation candidates from Tier-1 Indian cities
Employment Type: Full-time
Experience Required: 5–9 years

What you'd actually be doing:
Own the intelligence layer of Redrob's product — ranking, retrieval, and matching systems.
Ship a v2 ranking system with embeddings, hybrid retrieval, and LLM-based re-ranking.
Set up evaluation infrastructure — offline benchmarks, online A/B testing, recruiter-feedback loops.
Drive long-term architecture for candidate-JD matching at scale.
Mentor the next round of ML hires.

Things you absolutely need:
Production experience with embeddings-based retrieval systems (sentence-transformers, OpenAI embeddings, BGE, E5).
Production experience with vector databases or hybrid search infrastructure — Pinecone, Weaviate, Qdrant, Milvus, OpenSearch, Elasticsearch, FAISS.
Strong Python.
Hands-on experience designing evaluation frameworks for ranking systems — NDCG, MRR, MAP, A/B test interpretation.

Things we'd like you to have:
LLM fine-tuning experience (LoRA, QLoRA, PEFT).
Experience with learning-to-rank models (XGBoost-based or neural).
Prior exposure to HR-tech, recruiting tech, or marketplace products.
Background in distributed systems or large-scale inference optimization.
Open-source contributions in the AI/ML space.

Things we explicitly do NOT want:
Title-chasers. Switching companies every 1.5 years for title.
Framework enthusiasts with only LangChain tutorials.
People who have only worked at consulting firms (TCS, Infosys, Wipro, Accenture, Cognizant, Capgemini).
People whose primary expertise is computer vision, speech, or robotics.
People whose work has been entirely on closed-source proprietary systems.

Location: Pune/Noida-preferred. Hyderabad, Pune, Mumbai, Delhi NCR welcome.
Notice period: sub-30-day preferred. Can buy out up to 30 days.

The ideal candidate:
6-8 years total experience, 4-5 in applied ML/AI roles at product companies (not pure services).
Shipped at least one end-to-end ranking, search, or recommendation system to real users at meaningful scale.
Strong opinions about retrieval (hybrid vs dense), evaluation (offline vs online), LLM integration.
Located in or willing to relocate to Noida or Pune.
Active on Redrob platform.
"""
