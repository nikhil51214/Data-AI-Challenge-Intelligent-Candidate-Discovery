"""
src/output_generator.py
-----------------------
Produces the final outputs/ranked_candidates.csv that matches the
submission_spec exactly:

  candidate_id, rank, score, reasoning

Rules enforced:
- Exactly 100 rows
- Ranks 1–100 each appearing exactly once
- Scores non-increasing with rank
- Tie-break: candidate_id ascending
- UTF-8, .csv extension

Also writes a detailed JSON report for Stage 4 manual review.

Connects to: reranker.py + explainability.py → output_generator.py
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _enforce_score_monotone(rows: List[Dict]) -> List[Dict]:
    """
    Ensure scores are non-increasing with rank.
    If a score is higher than the previous, cap it.
    """
    for i in range(1, len(rows)):
        if rows[i]["score"] > rows[i - 1]["score"]:
            rows[i]["score"] = rows[i - 1]["score"]
    return rows


def _enforce_tie_break(rows: List[Dict]) -> List[Dict]:
    """
    For candidates with equal scores, sort by candidate_id ascending.
    Re-assign ranks after sort.
    """
    rows.sort(key=lambda r: (round(-r["score"], 6), r["candidate_id"]))
    for idx, row in enumerate(rows, start=1):
        row["rank"] = idx
    return rows


def generate_csv(
    ranked_items: List[Dict[str, Any]],
    output_path: str | Path,
    top_n: int = 100,
) -> Path:
    """
    Write the submission CSV.

    Parameters
    ----------
    ranked_items : list from reranker + explainability (must have 100+ items)
    output_path  : destination path
    top_n        : number of rows to write (100)

    Returns
    -------
    Path to written file
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if len(ranked_items) < top_n:
        raise ValueError(
            f"Need at least {top_n} candidates to fill submission, got {len(ranked_items)}"
        )

    # Build rows
    rows = []
    for item in ranked_items[:top_n]:
        rows.append({
            "candidate_id" : item["candidate_id"],
            "rank"         : item.get("rank", len(rows) + 1),
            "score"        : item.get("reranked_score", item.get("final_score", 0.0)),
            "reasoning"    : item.get("reasoning", ""),
        })

    # Ensure monotone scores and tie-break
    rows = _enforce_score_monotone(rows)
    rows = _enforce_tie_break(rows)

    # Write CSV
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["candidate_id", "rank", "score", "reasoning"],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "candidate_id" : row["candidate_id"],
                "rank"         : int(row["rank"]),
                "score"        : f"{row['score']:.6f}",
                "reasoning"    : row["reasoning"],
            })

    logger.info("Submission CSV written to %s (%d rows)", output_path, top_n)
    return output_path


def generate_detailed_report(
    ranked_items: List[Dict[str, Any]],
    output_path: str | Path,
    top_n: int = 100,
) -> Path:
    """
    Write a JSON report with full feature breakdown for each top-N candidate.
    Useful for Stage 4 manual review and internal debugging.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    report = []
    for item in ranked_items[:top_n]:
        feat = item.get("feat", {})
        report.append({
            "candidate_id"      : item["candidate_id"],
            "rank"              : item.get("rank"),
            "final_score"       : item.get("reranked_score", item.get("final_score")),
            "tfidf_similarity"  : item.get("tfidf_sim"),
            "reasoning"         : item.get("reasoning", ""),
            "component_scores"  : item.get("components", {}),
            "key_features"      : {
                "current_title"        : feat.get("current_title"),
                "years_of_experience"  : feat.get("years_of_experience"),
                "target_skill_hits"    : feat.get("target_skill_hits"),
                "has_production_ml"    : feat.get("has_production_ml"),
                "shipped_ranking"      : feat.get("shipped_ranking"),
                "product_fraction"     : round(feat.get("product_fraction", 0), 2),
                "consulting_fraction"  : round(feat.get("consulting_fraction", 0), 2),
                "last_active_days"     : feat.get("last_active_days"),
                "response_rate"        : feat.get("response_rate"),
                "notice_days"          : feat.get("notice_days"),
                "location"             : feat.get("location"),
                "willing_relocate"     : feat.get("willing_relocate"),
                "edu_tier"             : feat.get("edu_tier"),
                "is_honeypot"          : feat.get("is_honeypot"),
            },
        })

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    logger.info("Detailed report written to %s", output_path)
    return output_path
