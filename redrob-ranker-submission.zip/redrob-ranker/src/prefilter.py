"""
src/prefilter.py
----------------
Stage-0 fast pre-filter: scan raw JSONL cheaply (no full parsing)
to select ~5000 candidates worth running the full pipeline on.

Two-pass design mirrors real production systems:
  Pass 1: keyword scan on raw text (O(N) cheap)   → ~5 000 candidates
  Pass 2: full feature extraction + TF-IDF + scoring on that subset

This keeps RAM well under 16 GB and wall-clock under 5 minutes.
"""

from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import List, Set

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Keyword sets for Stage-0 filter
# ---------------------------------------------------------------------------

# Hard-required ML / AI signal keywords (at least 1 must match)
HARD_ML_KEYWORDS: Set[str] = {
    "embedding", "embeddings", "faiss", "pinecone", "weaviate", "qdrant",
    "milvus", "opensearch", "elasticsearch", "vector search", "vector database",
    "hybrid search", "information retrieval", "bm25", "sentence transformer",
    "ranking", "retrieval", "recommendation", "nlp", "natural language",
    "machine learning", "applied ml", "ml engineer", "ai engineer",
    "search engineer", "data scientist", "pytorch", "tensorflow",
    "hugging face", "huggingface", "fine-tun", "fine tuning", "lora", "peft",
    "langchain", "rag", "xgboost", "lightgbm", "scikit", "sklearn",
    "recommendation systems", "learning to rank", "ndcg", "mrr",
}

# Soft signals that boost inclusion (need at least 1 hard + any soft)
SOFT_BOOST_KEYWORDS: Set[str] = {
    "python", "data science", "deep learning", "neural", "transformer",
    "bert", "gpt", "llm", "mlops", "mlflow", "kubeflow",
    "a/b test", "evaluation", "production", "shipped", "deployed",
    "startup", "product company", "series",
}

# Disqualifying titles (fast-reject unless they also have strong ML signals)
FAST_REJECT_TITLES: Set[str] = {
    "accountant", "graphic designer", "civil engineer",
    "mechanical engineer", "marketing manager", "hr manager",
    "content writer", "customer support", "sales executive",
    "operations manager", "business analyst",
}


def prefilter_candidates(
    filepath: str | Path,
    max_pass: int = 5000,
) -> List[dict]:
    """
    Stream the JSONL file and return up to max_pass raw candidate records
    that pass the Stage-0 filter.

    Parameters
    ----------
    filepath : path to candidates.jsonl or .jsonl.gz
    max_pass : cap on candidates passed to the full pipeline

    Returns
    -------
    List of raw candidate dicts
    """
    import gzip

    path   = Path(filepath)
    opener = gzip.open if path.suffix == ".gz" else open
    mode   = "rt" if path.suffix == ".gz" else "r"

    t0         = time.time()
    passed     = []
    total      = 0
    rejected   = 0

    with opener(path, mode, encoding="utf-8") as fh:
        for raw_line in fh:
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            total += 1

            try:
                record = json.loads(raw_line)
            except json.JSONDecodeError:
                continue

            profile = record.get("profile", {})
            title   = profile.get("current_title", "").lower()
            signals = record.get("redrob_signals", {})

            # Fast-reject obvious non-ML roles (unless they have ML skills)
            is_bad_title = any(t in title for t in FAST_REJECT_TITLES)

            # Build quick text for keyword scan
            headline = profile.get("headline", "").lower()
            summary  = profile.get("summary", "").lower()
            skills   = " ".join(
                s.get("name", "").lower()
                for s in record.get("skills", [])
            )
            career_titles = " ".join(
                c.get("title", "").lower()
                for c in record.get("career_history", [])
            )
            career_descs = " ".join(
                c.get("description", "").lower()[:200]   # first 200 chars
                for c in record.get("career_history", [])
            )
            text = f"{title} {headline} {summary} {skills} {career_titles} {career_descs}"

            has_hard = any(kw in text for kw in HARD_ML_KEYWORDS)

            if is_bad_title and not has_hard:
                rejected += 1
                continue

            if not has_hard:
                rejected += 1
                continue

            passed.append(record)

    elapsed = time.time() - t0
    logger.info(
        "Pre-filter: %d/%d passed in %.1f s  (rejected %d)",
        len(passed), total, elapsed, rejected,
    )

    # If we got far more than needed, score them quickly and take the best
    if len(passed) > max_pass:
        logger.info("Trimming %d → %d via quick ML-signal count …", len(passed), max_pass)
        def quick_score(r: dict) -> int:
            skills_lower = {s.get("name","").lower() for s in r.get("skills",[])}
            return sum(1 for kw in HARD_ML_KEYWORDS if kw in skills_lower)
        passed.sort(key=quick_score, reverse=True)
        passed = passed[:max_pass]

    logger.info("Pre-filter kept %d candidates for full pipeline.", len(passed))
    return passed
