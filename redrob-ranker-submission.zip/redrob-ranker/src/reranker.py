"""
src/reranker.py
---------------
Re-ranks the top-K retrieved candidates using a richer cross-feature
score that goes beyond TF-IDF similarity.

Within the compute budget (5 min CPU, no network), we implement a
"cross-encoder-inspired" re-ranker using:

1. Skill intersection score  — keyword-level JD–candidate overlap
2. Anti-pattern filter       — penalises explicit JD disqualifiers
3. Engagement gate           — heavily penalises ghost candidates
4. Composite re-rank score   — blends retrieval score with rule-based signals

This is architecturally identical to how a cross-encoder would be used:
  pass all candidate–JD pairs through, get a refined score, re-sort.

When sentence-transformers is available, swap the similarity computation
with a real cross-encoder (e.g. cross-encoder/ms-marco-MiniLM-L-6-v2).

Connects to: retrieval.py → reranker.py → scoring.py
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Set, Tuple

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# JD disqualifier signals (from jd_parser)
# ──────────────────────────────────────────────────────────────────────────────

DISQUALIFIER_TITLE_PATTERNS = [
    r"marketing manager",
    r"graphic designer",
    r"civil engineer",
    r"mechanical engineer",
    r"accountant",
    r"sales executive",
    r"hr manager",
    r"content writer",
    r"customer support",
    r"operations manager",
]

DISQUALIFIER_SKILL_PATTERNS = [
    "photoshop", "illustrator", "salesforce", "tally", "accounting",
    "solidworks", "creo", "ansys",
]

HARD_REQUIRED_SIGNAL_SKILLS = {
    # At least ONE of these must be present for a top-10 candidate
    "embeddings", "vector search", "faiss", "pinecone", "weaviate", "qdrant",
    "milvus", "opensearch", "elasticsearch", "information retrieval",
    "sentence-transformers", "sentence transformers", "bm25", "ranking",
    "retrieval", "recommendation", "recommendation systems",
    "nlp", "natural language processing",
}


# ──────────────────────────────────────────────────────────────────────────────
# Re-ranker
# ──────────────────────────────────────────────────────────────────────────────

class RuleBasedReranker:
    """
    A fast, deterministic re-ranker that applies JD-specific filters and
    boosts to the top-K retrieval pool.

    Parameters
    ----------
    top_n  : final number of candidates to keep (100 for submission)
    pool_k : how many candidates to re-rank (should be retrieval top_k)
    """

    def __init__(self, top_n: int = 100, pool_k: int = 300) -> None:
        self.top_n  = top_n
        self.pool_k = pool_k

    def rerank(
        self,
        scored_candidates: List[Dict[str, Any]],
        jd_required_skills: List[str],
    ) -> List[Dict[str, Any]]:
        """
        Re-rank scored candidates.

        Parameters
        ----------
        scored_candidates : output of scoring.score_all(), sorted descending
        jd_required_skills: list of required skill strings from ParsedJD

        Returns
        -------
        Top-N candidates in final rank order (rank 1 = best)
        """
        jd_skills_set = {s.lower() for s in jd_required_skills}
        reranked = []

        for item in scored_candidates:
            feat  = item["feat"]
            score = item["final_score"]

            if feat.get("is_honeypot", False):
                continue

            # ── Disqualifier title penalty ────────────────────────────────
            title = feat.get("current_title", "").lower()
            if any(re.search(p, title) for p in DISQUALIFIER_TITLE_PATTERNS):
                score *= 0.25

            # ── Consulting-only hard penalty ──────────────────────────────
            if feat.get("consulting_fraction", 0.0) > 0.95:
                score *= 0.40

            # ── Ghost candidate hard penalty (inactive 6+ months) ─────────
            if feat.get("last_active_days", 999) > 180:
                score *= 0.50

            # ── Hard-required skill presence boost ────────────────────────
            skill_names = set(feat.get("skill_names", []))
            has_hard_req = bool(skill_names & HARD_REQUIRED_SIGNAL_SKILLS)
            if has_hard_req:
                score *= 1.10

            # ── Non-ML / non-CS disqualifier skills ───────────────────────
            disq_count = sum(1 for ds in DISQUALIFIER_SKILL_PATTERNS
                             if ds in skill_names)
            if disq_count >= 3:
                score *= max(0.6, 1.0 - disq_count * 0.05)

            # ── Product-company bonus (JD explicitly wants this) ───────────
            if feat.get("product_fraction", 0.0) > 0.5:
                score *= 1.05

            # ── Shipping bonus ─────────────────────────────────────────────
            if feat.get("shipped_ranking", False):
                score *= 1.08

            reranked.append({**item, "reranked_score": round(min(score, 1.0), 6)})

        # Sort by reranked score
        reranked.sort(key=lambda x: x["reranked_score"], reverse=True)

        # Take top N
        top = reranked[: self.top_n]

        # Assign ranks 1 … N
        for rank_idx, item in enumerate(top, start=1):
            item["rank"] = rank_idx

        logger.info(
            "Re-ranked to top %d; top reranked_score=%.4f",
            len(top),
            top[0]["reranked_score"] if top else 0,
        )
        return top
