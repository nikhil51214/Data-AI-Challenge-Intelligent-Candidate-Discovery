"""
src/retrieval.py
----------------
Top-K candidate retrieval using TF-IDF cosine similarity.
Architecture is FAISS-ready: swap in FaissRetriever when FAISS is available.

Connects to: embeddings.py → retrieval.py → reranker.py
"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import numpy as np

from .embeddings import TFIDFEmbedder, build_embedder

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# TF-IDF Retriever (default)
# ──────────────────────────────────────────────────────────────────────────────

class TFIDFRetriever:
    """
    Builds a TF-IDF index over all candidate text blobs and retrieves the
    top-K candidates most similar to the JD text blob.

    Parameters
    ----------
    top_k        : number of candidates to retrieve for re-ranking
    max_features : TF-IDF vocabulary size
    """

    def __init__(
        self,
        top_k: int = 300,
        max_features: int = 50_000,
    ) -> None:
        self.top_k   = top_k
        self.embedder = TFIDFEmbedder(max_features=max_features, ngram_range=(1, 2))
        self._built  = False

    def build_index(
        self,
        candidate_features: List[Dict],
    ) -> "TFIDFRetriever":
        """
        Fit the TF-IDF model on all candidate text blobs.

        Parameters
        ----------
        candidate_features : list of parsed candidate feature dicts
                             (from candidate_parser.parse_candidate)
        """
        texts = [c["text_blob"] for c in candidate_features]
        ids   = [c["candidate_id"] for c in candidate_features]
        self.embedder.fit(texts, ids)
        self._built = True
        logger.info("TF-IDF index built over %d candidates.", len(texts))
        return self

    def retrieve(
        self,
        jd_text_blob: str,
    ) -> Tuple[List[str], np.ndarray]:
        """
        Return top-K candidate IDs and their cosine similarity scores.

        Returns
        -------
        (ids, scores) both sorted descending by score
        """
        if not self._built:
            raise RuntimeError("Call build_index() before retrieve().")
        ids, scores = self.embedder.query(jd_text_blob, top_k=self.top_k)
        logger.info("Retrieved %d candidates (top score=%.4f).", len(ids), scores[0] if len(scores) else 0)
        return ids, scores


# ──────────────────────────────────────────────────────────────────────────────
# FAISS Retriever (optional drop-in when faiss-cpu is installed)
# ──────────────────────────────────────────────────────────────────────────────

class FaissRetriever:
    """
    Uses FAISS IVF index for sub-linear approximate nearest-neighbour search.
    Requires: faiss-cpu  AND  sentence-transformers.

    Drop-in replacement: same API as TFIDFRetriever.
    """

    def __init__(self, top_k: int = 300, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        try:
            import faiss
            from sentence_transformers import SentenceTransformer
            self.faiss = faiss
            self.model = SentenceTransformer(model_name)
        except ImportError as e:
            raise ImportError(f"FaissRetriever requires faiss-cpu and sentence-transformers: {e}")
        self.top_k       = top_k
        self._index      = None
        self._ids: List[str] = []

    def build_index(self, candidate_features: List[Dict]) -> "FaissRetriever":
        texts = [c["text_blob"] for c in candidate_features]
        self._ids = [c["candidate_id"] for c in candidate_features]
        logger.info("Encoding %d candidates for FAISS …", len(texts))
        embs = self.model.encode(texts, batch_size=64, convert_to_numpy=True,
                                  show_progress_bar=True).astype("float32")
        self.faiss.normalize_L2(embs)
        d = embs.shape[1]
        nlist = min(int(len(texts) ** 0.5), 256)
        quantiser = self.faiss.IndexFlatIP(d)
        self._index = self.faiss.IndexIVFFlat(quantiser, d, nlist, self.faiss.METRIC_INNER_PRODUCT)
        self._index.train(embs)
        self._index.add(embs)
        self._index.nprobe = 32
        logger.info("FAISS IVF index built: d=%d  nlist=%d  total=%d", d, nlist, self._index.ntotal)
        return self

    def retrieve(self, jd_text_blob: str) -> Tuple[List[str], np.ndarray]:
        jd_emb = self.model.encode([jd_text_blob], convert_to_numpy=True).astype("float32")
        self.faiss.normalize_L2(jd_emb)
        scores, indices = self._index.search(jd_emb, self.top_k)
        ids    = [self._ids[i] for i in indices[0] if i >= 0]
        sims   = scores[0][: len(ids)]
        return ids, sims


# ──────────────────────────────────────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────────────────────────────────────

def build_retriever(top_k: int = 300, use_faiss: bool = False) -> TFIDFRetriever:
    """Return best available retriever."""
    if use_faiss:
        try:
            return FaissRetriever(top_k=top_k)
        except ImportError:
            logger.warning("FAISS unavailable; falling back to TF-IDF retriever.")
    return TFIDFRetriever(top_k=top_k)
