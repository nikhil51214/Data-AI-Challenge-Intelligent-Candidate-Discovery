"""
src/scoring.py
--------------
Multi-signal scoring engine. Produces a final composite score for each
candidate against the JD.

Component scores
----------------
1. skill_match_score    — weighted TF-IDF + skill-proficiency overlap
2. experience_score     — YOE + product-company fraction + production ML
3. career_growth_score  — title progression, tenure, anti-job-hopping
4. domain_score         — ranking/retrieval/search shipped, ML title
5. behavioral_score     — engagement signals (activity, response, github …)
6. location_score       — target-city fit or willing to relocate
7. edu_score            — institution tier, CS/STEM field
8. honeypot_penalty     — hard zero-out for honeypots

Final score = weighted combination, then behavioral multiplier applied.

Connects to: candidate_parser.py → scoring.py → explainability.py → output
"""

from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Weights (must sum to 1.0)
# ──────────────────────────────────────────────────────────────────────────────

WEIGHTS = {
    "skill_match":     0.30,
    "experience":      0.20,
    "career_growth":   0.10,
    "domain":          0.20,
    "behavioral":      0.10,
    "location":        0.05,
    "edu":             0.05,
}
assert abs(sum(WEIGHTS.values()) - 1.0) < 1e-6, "Weights must sum to 1.0"


# ──────────────────────────────────────────────────────────────────────────────
# Individual sub-scorers  (all return 0.0 – 1.0)
# ──────────────────────────────────────────────────────────────────────────────

def skill_match_score(
    feat: Dict[str, Any],
    tfidf_sim: float = 0.0,
) -> float:
    """
    Combines:
    - TF-IDF cosine similarity to JD (semantic layer)
    - Direct target-skill hit count (lexical layer)
    - Weighted skill score (proficiency × endorsements × duration)
    """
    # Normalize tfidf_sim (typically 0 – 0.5 range for TF-IDF)
    tfidf_norm      = min(tfidf_sim / 0.35, 1.0)

    # Skill hit coverage
    num_hits        = feat.get("num_target_skills", 0)
    coverage        = min(num_hits / 10.0, 1.0)   # 10+ hits → 1.0

    # Weighted skill quality score (0–10 raw, normalised to 0–1)
    skill_quality   = min(feat.get("skill_score_raw", 0.0) / 6.0, 1.0)

    # Consulting-company penalty: if whole career is consulting, skills may be inflated
    cons_penalty    = max(0.0, 1.0 - feat.get("consulting_fraction", 0.0) * 0.4)

    raw = 0.35 * tfidf_norm + 0.35 * coverage + 0.30 * skill_quality
    return min(raw * cons_penalty, 1.0)


def experience_score(feat: Dict[str, Any]) -> float:
    """
    YOE in [5, 9] range + production ML background + product-company fraction.
    Penalises candidates who ONLY worked at IT services / consulting.
    """
    yoe             = feat.get("years_of_experience", 0)

    # YOE score: sweet spot 5–9 yrs
    if 5 <= yoe <= 9:
        yoe_score   = 1.0
    elif 4 <= yoe < 5:
        yoe_score   = 0.8
    elif 9 < yoe <= 12:
        yoe_score   = 0.85
    elif yoe > 12:
        yoe_score   = 0.65   # may have over-shot into pure management
    elif 3 <= yoe < 4:
        yoe_score   = 0.6
    else:
        yoe_score   = 0.3

    # Product company bonus
    prod_score      = min(feat.get("product_fraction", 0.0) * 1.5, 1.0)

    # ML / AI fraction in career
    ml_frac         = feat.get("ml_ai_fraction", 0.0)

    # Production ML hard bonus
    has_prod        = 1.0 if feat.get("has_production_ml", False) else 0.4

    return 0.30 * yoe_score + 0.30 * prod_score + 0.20 * ml_frac + 0.20 * has_prod


def career_growth_score(feat: Dict[str, Any]) -> float:
    """
    Rewards steady progression and long tenures.
    Penalises job-hopping (>3 jobs in 3 years).
    """
    progression     = feat.get("title_progression", 0.5)
    avg_tenure      = feat.get("avg_tenure_months", 24)
    jobs_3yr        = feat.get("job_count_3yr", 1)

    # Tenure: 18+ months is healthy
    tenure_score    = min(avg_tenure / 24.0, 1.0)

    # Job-hopping penalty
    if jobs_3yr <= 2:
        hopping_pen = 1.0
    elif jobs_3yr == 3:
        hopping_pen = 0.8
    else:
        hopping_pen = max(0.4, 1.0 - (jobs_3yr - 3) * 0.15)

    return (0.5 * progression + 0.3 * tenure_score + 0.2) * hopping_pen


def domain_score(feat: Dict[str, Any]) -> float:
    """
    Rewards candidates who have actually shipped ranking / retrieval / recommendation
    systems — the core of what the JD needs.
    """
    shipped         = 1.0 if feat.get("shipped_ranking", False) else 0.0
    is_ml           = 1.0 if feat.get("is_ml_title", False)    else 0.3
    ml_frac         = feat.get("ml_ai_fraction", 0.0)

    # Direct consulting-only penalty
    cons_only       = feat.get("consulting_fraction", 0.0) > 0.9
    base            = 0.5 * shipped + 0.3 * is_ml + 0.2 * ml_frac
    if cons_only:
        base        *= 0.5
    return min(base, 1.0)


def behavioral_score(feat: Dict[str, Any]) -> float:
    """
    Engagement multiplier: active candidates with good response rates
    and interview completion are prioritised.
    """
    # Activity recency
    days_inactive   = feat.get("last_active_days", 999)
    if days_inactive < 7:
        activity    = 1.0
    elif days_inactive < 30:
        activity    = 0.85
    elif days_inactive < 90:
        activity    = 0.65
    elif days_inactive < 180:
        activity    = 0.40
    else:
        activity    = 0.15

    # Open-to-work flag
    otw_bonus       = 0.1 if feat.get("open_to_work", False) else 0.0

    # Response rate
    resp            = feat.get("response_rate", 0.0)

    # Interview completion
    interview       = feat.get("interview_completion", 0.0)

    # GitHub activity
    gh              = min(feat.get("github_score", 0) / 60.0, 1.0)

    # Profile completeness
    pc              = feat.get("profile_completeness", 0.0) / 100.0

    # Notice-period fit (sub-30 days = 1.0, 30–60 = 0.8, 60–90 = 0.6, 90+ = 0.4)
    notice          = feat.get("notice_days", 90)
    if notice <= 30:
        notice_s    = 1.0
    elif notice <= 60:
        notice_s    = 0.8
    elif notice <= 90:
        notice_s    = 0.6
    else:
        notice_s    = max(0.3, 1.0 - notice / 250)

    raw = (
        0.30 * activity
        + 0.20 * resp
        + 0.15 * interview
        + 0.10 * gh
        + 0.10 * pc
        + 0.10 * notice_s
        + 0.05 * otw_bonus
    )
    return min(raw, 1.0)


def location_score(feat: Dict[str, Any]) -> float:
    return 1.0 if feat.get("in_target_location", False) else 0.3


def education_score(feat: Dict[str, Any]) -> float:
    tier      = feat.get("edu_tier", 4)
    is_stem   = feat.get("is_cs_stem", False)
    tier_s    = {1: 1.0, 2: 0.8, 3: 0.65, 4: 0.5}.get(tier, 0.5)
    stem_s    = 0.15 if is_stem else 0.0
    return min(tier_s + stem_s, 1.0)


# ──────────────────────────────────────────────────────────────────────────────
# Composite scorer
# ──────────────────────────────────────────────────────────────────────────────

def compute_composite_score(
    feat: Dict[str, Any],
    tfidf_sim: float = 0.0,
) -> Tuple[float, Dict[str, float]]:
    """
    Compute the final composite score and the breakdown dict.

    Returns
    -------
    (final_score, component_scores_dict)
    final_score: float in [0, 1]
    """
    if feat.get("is_honeypot", False):
        components = {k: 0.0 for k in WEIGHTS}
        components["honeypot_penalty"] = -1.0
        return 0.0, components

    sm  = skill_match_score(feat, tfidf_sim)
    ex  = experience_score(feat)
    cg  = career_growth_score(feat)
    dm  = domain_score(feat)
    bh  = behavioral_score(feat)
    lc  = location_score(feat)
    ed  = education_score(feat)

    components = {
        "skill_match"   : round(sm,  4),
        "experience"    : round(ex,  4),
        "career_growth" : round(cg,  4),
        "domain"        : round(dm,  4),
        "behavioral"    : round(bh,  4),
        "location"      : round(lc,  4),
        "edu"           : round(ed,  4),
    }

    weighted_sum = sum(WEIGHTS[k] * components[k] for k in WEIGHTS)

    # Behavioral availability multiplier: ghost candidates get downweighted
    availability = 0.5 + 0.5 * bh
    final = weighted_sum * availability

    return round(min(final, 1.0), 6), components


def score_all(
    candidate_features: List[Dict[str, Any]],
    tfidf_scores_map: Dict[str, float],
) -> List[Dict[str, Any]]:
    """
    Score every candidate and return a list of result dicts,
    sorted descending by final score.

    Parameters
    ----------
    candidate_features : list of parsed feature dicts
    tfidf_scores_map   : {candidate_id: cosine_similarity_score}

    Returns
    -------
    List of dicts with keys: candidate_id, final_score, components, …
    """
    results = []
    for feat in candidate_features:
        cid       = feat["candidate_id"]
        tfidf_sim = tfidf_scores_map.get(cid, 0.0)
        score, comps = compute_composite_score(feat, tfidf_sim)
        results.append({
            "candidate_id"    : cid,
            "final_score"     : score,
            "tfidf_sim"       : round(tfidf_sim, 4),
            "components"      : comps,
            "is_honeypot"     : feat.get("is_honeypot", False),
            # pass-through for explainability
            "feat"            : feat,
        })

    results.sort(key=lambda x: x["final_score"], reverse=True)
    logger.info("Scored %d candidates; top score = %.4f", len(results), results[0]["final_score"] if results else 0)
    return results
