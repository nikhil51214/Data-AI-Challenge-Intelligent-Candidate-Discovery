"""
tests/test_pipeline.py
Unit and integration tests for the Redrob ranking pipeline.
Run with: python -m pytest tests/ -v
"""

import sys, json, tempfile, os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.jd_parser         import parse_jd, JD_TEXT
from src.candidate_parser  import parse_candidate
from src.scoring           import compute_composite_score, skill_match_score
from src.explainability    import generate_reasoning
from src.evaluation        import ndcg_at_k, precision_at_k, recall_at_k, average_precision
from src.output_generator  import generate_csv


# ── Fixtures ──────────────────────────────────────────────────────────────────

def _make_candidate(overrides=None):
    base = {
        "candidate_id": "CAND_0000001",
        "profile": {
            "anonymized_name": "Test User",
            "headline": "Senior ML Engineer | Embeddings & Retrieval",
            "summary": "Built FAISS-based retrieval at Flipkart.",
            "location": "Bangalore, Karnataka",
            "country": "India",
            "years_of_experience": 7.0,
            "current_title": "ML Engineer",
            "current_company": "Flipkart",
            "current_company_size": "10001+",
            "current_industry": "E-commerce",
        },
        "career_history": [{
            "company": "Flipkart",
            "title": "ML Engineer",
            "start_date": "2019-01-01",
            "end_date": None,
            "duration_months": 60,
            "is_current": True,
            "industry": "E-commerce",
            "company_size": "10001+",
            "description": "Built FAISS vector search and embedding-based ranking system deployed to production.",
        }],
        "education": [{"institution": "IIT Bombay", "degree": "B.Tech",
                        "field_of_study": "Computer Science",
                        "start_year": 2012, "end_year": 2016,
                        "grade": "8.5 CGPA", "tier": "tier_1"}],
        "skills": [
            {"name": "FAISS", "proficiency": "expert", "endorsements": 45, "duration_months": 36},
            {"name": "Embeddings", "proficiency": "advanced", "endorsements": 30, "duration_months": 48},
            {"name": "Python", "proficiency": "expert", "endorsements": 60, "duration_months": 72},
            {"name": "Ranking", "proficiency": "advanced", "endorsements": 20, "duration_months": 36},
        ],
        "redrob_signals": {
            "profile_completeness_score": 90.0,
            "signup_date": "2025-01-01",
            "last_active_date": "2026-06-01",
            "open_to_work_flag": True,
            "profile_views_received_30d": 150,
            "applications_submitted_30d": 3,
            "recruiter_response_rate": 0.85,
            "avg_response_time_hours": 12.0,
            "skill_assessment_scores": {"FAISS": 88.0},
            "connection_count": 800,
            "endorsements_received": 120,
            "notice_period_days": 30,
            "expected_salary_range_inr_lpa": {"min": 25.0, "max": 50.0},
            "preferred_work_mode": "hybrid",
            "willing_to_relocate": True,
            "github_activity_score": 72.0,
            "search_appearance_30d": 400,
            "saved_by_recruiters_30d": 20,
            "interview_completion_rate": 0.9,
            "offer_acceptance_rate": 0.7,
            "verified_email": True,
            "verified_phone": True,
            "linkedin_connected": True,
        },
    }
    if overrides:
        base.update(overrides)
    return base


# ── JD Parser ─────────────────────────────────────────────────────────────────

def test_jd_parser_returns_required_skills():
    pjd = parse_jd(JD_TEXT)
    assert len(pjd.required_skills) >= 5
    assert pjd.experience_min_years == 5
    assert pjd.experience_max_years == 9
    assert "india" in [l.lower() for l in pjd.target_locations] or len(pjd.target_locations) >= 2
    assert len(pjd.text_blob) > 100

def test_jd_parser_faiss_in_skills():
    pjd = parse_jd(JD_TEXT)
    skills_lower = [s.lower() for s in pjd.required_skills]
    assert "faiss" in skills_lower or any("faiss" in s for s in skills_lower)


# ── Candidate Parser ──────────────────────────────────────────────────────────

def test_candidate_parser_basic():
    feat = parse_candidate(_make_candidate())
    assert feat["candidate_id"] == "CAND_0000001"
    assert feat["years_of_experience"] == 7.0
    assert "faiss" in feat["target_skill_hits"]
    assert feat["has_production_ml"] is True
    assert feat["shipped_ranking"] is True
    assert feat["edu_tier"] == 1
    assert feat["is_cs_stem"] is True
    assert feat["is_honeypot"] is False

def test_honeypot_detection_expert_zero_duration():
    rec = _make_candidate()
    rec["skills"] = [
        {"name": f"Skill{i}", "proficiency": "expert",
         "endorsements": 50, "duration_months": 0}
        for i in range(5)
    ]
    feat = parse_candidate(rec)
    assert feat["is_honeypot"] is True

def test_candidate_text_blob_not_empty():
    feat = parse_candidate(_make_candidate())
    assert len(feat["text_blob"]) > 50


# ── Scoring ───────────────────────────────────────────────────────────────────

def test_composite_score_range():
    feat = parse_candidate(_make_candidate())
    score, comps = compute_composite_score(feat, tfidf_sim=0.3)
    assert 0.0 <= score <= 1.0
    assert set(comps.keys()) >= {"skill_match", "experience", "domain", "behavioral"}

def test_honeypot_scores_zero():
    rec  = _make_candidate()
    rec["skills"] = [
        {"name": f"S{i}", "proficiency": "expert", "endorsements": 50, "duration_months": 0}
        for i in range(5)
    ]
    feat = parse_candidate(rec)
    assert feat["is_honeypot"] is True
    score, _ = compute_composite_score(feat, 0.5)
    assert score == 0.0

def test_inactive_candidate_lower_score():
    good_rec = _make_candidate()
    ghost_rec = _make_candidate()
    ghost_rec["redrob_signals"]["last_active_date"] = "2025-01-01"  # 500+ days ago
    ghost_rec["redrob_signals"]["recruiter_response_rate"] = 0.03

    feat_good  = parse_candidate(good_rec)
    feat_ghost = parse_candidate(ghost_rec)
    score_good,  _ = compute_composite_score(feat_good,  0.3)
    score_ghost, _ = compute_composite_score(feat_ghost, 0.3)
    assert score_good > score_ghost


# ── Evaluation Metrics ────────────────────────────────────────────────────────

def test_precision_at_k():
    ranked   = ["A", "B", "C", "D", "E"]
    relevant = {"A", "C", "E"}
    assert precision_at_k(ranked, relevant, 5) == 3/5
    assert precision_at_k(ranked, relevant, 1) == 1.0

def test_recall_at_k():
    ranked   = ["A", "B", "C", "D", "E"]
    relevant = {"A", "C", "E"}
    assert recall_at_k(ranked, relevant, 3) == 2/3

def test_ndcg_perfect():
    ids = ["A", "B", "C"]
    rel = {"A": 3, "B": 2, "C": 1}
    assert abs(ndcg_at_k(ids, rel, 3) - 1.0) < 1e-6

def test_ndcg_worst():
    ids = ["C", "B", "A"]
    rel = {"A": 3, "B": 0, "C": 0}
    assert ndcg_at_k(ids, rel, 3) < 1.0

def test_average_precision():
    ranked   = ["A", "B", "C", "D"]
    relevant = {"A", "C"}
    ap = average_precision(ranked, relevant)
    assert abs(ap - (1.0/1 + 2.0/3) / 2) < 1e-6


# ── Explainability ────────────────────────────────────────────────────────────

def test_reasoning_not_empty():
    feat  = parse_candidate(_make_candidate())
    item  = {"feat": feat, "rank": 1, "reranked_score": 0.95,
             "components": {}, "candidate_id": feat["candidate_id"]}
    r = generate_reasoning(item)
    assert isinstance(r, str) and len(r) > 30

def test_reasoning_mentions_title():
    feat = parse_candidate(_make_candidate())
    item = {"feat": feat, "rank": 5, "reranked_score": 0.80, "components": {}}
    r = generate_reasoning(item)
    assert "ML Engineer" in r or "engineer" in r.lower()


# ── Output Generator ──────────────────────────────────────────────────────────

def test_generate_csv_creates_valid_file():
    items = []
    for i in range(100):
        feat = parse_candidate(_make_candidate({"candidate_id": f"CAND_{i+1:07d}"}))
        score = max(0.01, 1.0 - i * 0.009)
        items.append({
            "candidate_id"  : feat["candidate_id"],
            "rank"          : i + 1,
            "reranked_score": score,
            "final_score"   : score,
            "reasoning"     : f"Candidate {i+1} reasoning.",
            "feat"          : feat,
            "components"    : {},
        })

    with tempfile.TemporaryDirectory() as tmpdir:
        out_path = os.path.join(tmpdir, "test_submission.csv")
        generate_csv(items, out_path, top_n=100)
        assert os.path.exists(out_path)
        with open(out_path) as f:
            lines = f.readlines()
        assert len(lines) == 101   # header + 100 data rows


if __name__ == "__main__":
    import traceback
    tests = [
        test_jd_parser_returns_required_skills,
        test_jd_parser_faiss_in_skills,
        test_candidate_parser_basic,
        test_honeypot_detection_expert_zero_duration,
        test_candidate_text_blob_not_empty,
        test_composite_score_range,
        test_honeypot_scores_zero,
        test_inactive_candidate_lower_score,
        test_precision_at_k,
        test_recall_at_k,
        test_ndcg_perfect,
        test_ndcg_worst,
        test_average_precision,
        test_reasoning_not_empty,
        test_reasoning_mentions_title,
        test_generate_csv_creates_valid_file,
    ]
    passed = 0; failed = 0
    for t in tests:
        try:
            t(); print(f"  ✅  {t.__name__}"); passed += 1
        except Exception as e:
            print(f"  ❌  {t.__name__}: {e}"); traceback.print_exc(); failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed")
